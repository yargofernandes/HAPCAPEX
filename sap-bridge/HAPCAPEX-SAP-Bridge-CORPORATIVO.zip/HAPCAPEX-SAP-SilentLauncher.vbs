Option Explicit

Dim shell, root, psExe, launcher, protocol, command
Set shell = CreateObject("WScript.Shell")

root = shell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\HAPCAPEX\SapBridge"
psExe = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"
launcher = root & "\HAPCAPEX-SAP-Launcher.ps1"
protocol = "hapcapex-sap://start"

If WScript.Arguments.Count > 0 Then
    protocol = CStr(WScript.Arguments(0))
End If

command = QuoteArg(psExe) & _
          " -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & QuoteArg(launcher) & _
          " -Protocol " & QuoteArg(protocol)

' WindowStyle 0 = totalmente oculto; False = não bloquear o chamador.
shell.Run command, 0, False

Function QuoteArg(ByVal value)
    QuoteArg = Chr(34) & Replace(CStr(value), Chr(34), Chr(34) & Chr(34)) & Chr(34)
End Function
