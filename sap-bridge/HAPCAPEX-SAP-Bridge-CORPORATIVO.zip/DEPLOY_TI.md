﻿# DEPLOY T.I.
Versão: 1.1.4-alpha
Escopo: CurrentUser
Porta: 127.0.0.1:17891

IMPORTANTE: implantar em contexto do usuário logado, pois o Bridge precisa acessar a sessão SAP GUI interativa.
