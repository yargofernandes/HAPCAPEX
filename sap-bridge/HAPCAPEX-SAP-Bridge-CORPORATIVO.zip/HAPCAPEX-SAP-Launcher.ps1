﻿param(
    [string]$Protocol = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'SilentlyContinue'

$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$BridgePath = Join-Path $Root 'HAPCAPEX-SAP-Bridge.ps1'
$UpdaterPath = Join-Path $Root 'Atualizar-HAPCAPEX-SAP-Bridge.ps1'
$DiagnosticPath = Join-Path $Root 'Diagnostico-MacroBridge.cmd'

function Test-BridgeOnline {
    try {
        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:17891/api/health' -Method Get -TimeoutSec 1
        return [bool]$health.ok
    } catch {
        return $false
    }
}

function Start-HiddenPowerShell {
    param(
        [Parameter(Mandatory=$true)][string]$ScriptPath,
        [string[]]$ExtraArguments = @(),
        [switch]$Sta
    )

    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden')
    if ($Sta) { $args += '-STA' }
    $args += @('-File',('"' + $ScriptPath + '"'))
    foreach ($item in $ExtraArguments) {
        $args += ('"' + ([string]$item).Replace('"','\"') + '"')
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $psExe
    $psi.Arguments = ($args -join ' ')
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    [void][System.Diagnostics.Process]::Start($psi)
}

$uri = [string]$Protocol

if ($uri -match '^hapcapex-sap://update') {
    if (Test-Path -LiteralPath $UpdaterPath) {
        # O próprio launcher já nasceu oculto via wscript.exe.
        # Executar o updater no mesmo processo evita criar qualquer console filho.
        & $UpdaterPath -Silent
    }
    exit 0
}

if ($uri -match '^hapcapex-sap://diagnose') {
    if (Test-Path -LiteralPath $DiagnosticPath) {
        Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', 'start', '""', $DiagnosticPath) | Out-Null
    }
    exit 0
}

if (-not (Test-BridgeOnline)) {
    if (Test-Path -LiteralPath $BridgePath) {
        Start-HiddenPowerShell -ScriptPath $BridgePath -Sta
    }
}
