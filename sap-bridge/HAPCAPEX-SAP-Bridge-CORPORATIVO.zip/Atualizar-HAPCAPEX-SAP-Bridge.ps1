﻿param(
    [switch]$Silent
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ManifestUrl = 'https://yargofernandes.github.io/HAPCAPEX/sap-bridge/latest.json'
$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$LogPath = Join-Path $Root 'updater.log'
$InstallJsonPath = Join-Path $Root 'install.json'

function Write-UpdateLog {
    param([Parameter(Mandatory=$true)][string]$Text)

    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    Add-Content -LiteralPath $LogPath -Value ('{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text) -Encoding UTF8
    if (-not $Silent) {
        Write-Host $Text
    }
}

function Compare-VersionNumbers {
    param(
        [string]$A,
        [string]$B
    )

    $matchA = [regex]::Match([string]$A, '(\d+)\.(\d+)\.(\d+)')
    $matchB = [regex]::Match([string]$B, '(\d+)\.(\d+)\.(\d+)')

    if (-not $matchA.Success -or -not $matchB.Success) {
        return [string]::Compare([string]$A, [string]$B, $true)
    }

    for ($i = 1; $i -le 3; $i++) {
        $partA = [int]$matchA.Groups[$i].Value
        $partB = [int]$matchB.Groups[$i].Value
        if ($partA -gt $partB) { return 1 }
        if ($partA -lt $partB) { return -1 }
    }

    return 0
}

function Get-CurrentBridgeInfo {
    $result = [ordered]@{
        version = ''
        distributionVersion = ''
    }

    try {
        $health = Invoke-RestMethod -Uri 'http://127.0.0.1:17891/api/health' -Method Get -TimeoutSec 1
        if ($health.ok) {
            $result.version = [string]$health.version
            if ($health.PSObject.Properties.Name -contains 'distributionVersion') {
                $result.distributionVersion = [string]$health.distributionVersion
            }
            return [pscustomobject]$result
        }
    } catch {}

    try {
        if (Test-Path -LiteralPath $InstallJsonPath) {
            $installed = Get-Content -LiteralPath $InstallJsonPath -Raw | ConvertFrom-Json
            $result.version = [string]$installed.version
            if ($installed.PSObject.Properties.Name -contains 'distributionVersion') {
                $result.distributionVersion = [string]$installed.distributionVersion
            }
        }
    } catch {}

    return [pscustomobject]$result
}

function Wait-UpdatedBridgeHealth {
    param(
        [Parameter(Mandatory=$true)][string]$ExpectedVersion,
        [string]$ExpectedDistributionVersion = '',
        [int]$Seconds = 20
    )

    $deadline = (Get-Date).AddSeconds($Seconds)
    do {
        Start-Sleep -Milliseconds 500
        try {
            $health = Invoke-RestMethod -Uri 'http://127.0.0.1:17891/api/health' -Method Get -TimeoutSec 1
            if ($health.ok -and ([string]$health.version -eq $ExpectedVersion)) {
                if ($ExpectedDistributionVersion) {
                    if (-not ($health.PSObject.Properties.Name -contains 'distributionVersion')) {
                        continue
                    }
                    if ([string]$health.distributionVersion -ne $ExpectedDistributionVersion) {
                        continue
                    }
                }
                return $health
            }
        } catch {}
    } while ((Get-Date) -lt $deadline)

    return $null
}

$tempRoot = Join-Path $env:TEMP ('HAPCAPEX-SAP-Update-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    Write-UpdateLog -Text 'Consultando versão corporativa...'

    $cacheBust = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $manifest = Invoke-RestMethod -Uri ($ManifestUrl + '?t=' + $cacheBust) -Method Get -TimeoutSec 20

    $latestVersion = [string]$manifest.version
    $latestDistributionVersion = ''
    if ($manifest.PSObject.Properties.Name -contains 'distributionVersion') {
        $latestDistributionVersion = [string]$manifest.distributionVersion
    }

    $current = Get-CurrentBridgeInfo
    $productCompare = Compare-VersionNumbers -A $current.version -B $latestVersion
    $distributionCompare = 0
    if ($current.distributionVersion -and $latestDistributionVersion) {
        $distributionCompare = Compare-VersionNumbers -A $current.distributionVersion -B $latestDistributionVersion
    }

    # Nunca fazer downgrade automático. Isso protege uma instalação piloto/nova
    # quando o latest.json do GitHub ainda aponta para um pacote mais antigo.
    if ($current.version -and ($productCompare -gt 0)) {
        Write-UpdateLog -Text ('Manifesto remoto é mais antigo que o Bridge instalado. Mantendo {0}.' -f $current.version)
        exit 0
    }

    if ($productCompare -eq 0) {
        if (-not $latestDistributionVersion) {
            Write-UpdateLog -Text ('Bridge já atualizado: {0}' -f $latestVersion)
            exit 0
        }

        if ($current.distributionVersion -and ($distributionCompare -ge 0)) {
            Write-UpdateLog -Text ('Bridge já atualizado: {0} / pacote local {1} (remoto {2})' -f $latestVersion, $current.distributionVersion, $latestDistributionVersion)
            exit 0
        }
    }

    $zipPath = Join-Path $tempRoot 'bridge.zip'
    Invoke-WebRequest -Uri ([string]$manifest.packageUrl) -OutFile $zipPath -UseBasicParsing -TimeoutSec 120

    $actualSha = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $expectedSha = ([string]$manifest.sha256).ToLowerInvariant()
    if ($actualSha -ne $expectedSha) {
        throw 'SHA256 do pacote não confere. A atualização foi cancelada.'
    }

    $packageDir = Join-Path $tempRoot 'pkg'
    Expand-Archive -LiteralPath $zipPath -DestinationPath $packageDir -Force

    $installerPath = Join-Path $packageDir 'Instalar-HAPCAPEX-SAP-Bridge.ps1'
    if (-not (Test-Path -LiteralPath $installerPath)) {
        throw 'Instalador ausente no pacote baixado.'
    }

    Write-UpdateLog -Text ('Atualizando {0} -> {1}' -f $current.version, $latestVersion)

    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $psExe
    $psi.Arguments = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Silent -Source "online-update"' -f $installerPath)
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden

    $process = [System.Diagnostics.Process]::Start($psi)
    if ($null -eq $process) {
        throw 'Não foi possível iniciar o instalador em segundo plano.'
    }

    if (-not $process.WaitForExit(90000)) {
        try { $process.Kill() } catch {}
        throw 'O instalador não finalizou em até 90 segundos.'
    }

    $installerExitCode = $process.ExitCode
    if ($installerExitCode -ne 0) {
        $installerLog = Join-Path $Root 'installer.log'
        $details = ''
        if (Test-Path -LiteralPath $installerLog) {
            try {
                $tail = Get-Content -LiteralPath $installerLog -Tail 8 -ErrorAction Stop
                if ($tail) {
                    $details = ' Último registro: ' + (($tail -join ' | ').Trim())
                }
            } catch {}
        }
        throw ('Instalador retornou código {0}.{1}' -f $installerExitCode, $details)
    }

    # O Bridge pode ficar alguns segundos indisponível durante a troca do processo.
    # Uma única chamada de health-check gerava falso erro mesmo após instalação concluída.
    $health = Wait-UpdatedBridgeHealth -ExpectedVersion $latestVersion -ExpectedDistributionVersion $latestDistributionVersion -Seconds 20
    if ($null -eq $health) {
        throw ('A instalação terminou, mas o Bridge {0} não respondeu ao health-check em até 20 segundos.' -f $latestVersion)
    }

    Write-UpdateLog -Text ('Atualização concluída: {0} / pacote {1}' -f $latestVersion, $latestDistributionVersion)
    exit 0
} catch {
    Write-UpdateLog -Text ('ERRO: {0}' -f $_.Exception.Message)
    if (-not $Silent) {
        Write-Host ''
        Write-Host 'Atualização não concluída.' -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Yellow
        Read-Host 'ENTER para fechar' | Out-Null
    }
    exit 2
} finally {
    Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
