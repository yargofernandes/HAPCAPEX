﻿param(
    [switch]$Silent,
    [switch]$NoStart,
    [string]$Source = 'manual'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ExpectedVersion = '1.1.7-alpha'
$DistributionVersion = '1.0.11'
$Port = 17891
$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$BackupRoot = Join-Path $Root 'rollback'
$LogPath = Join-Path $Root 'installer.log'
$PidPath = Join-Path $Root 'bridge.pid'
$BridgePath = Join-Path $Root 'HAPCAPEX-SAP-Bridge.ps1'
$InstallJsonPath = Join-Path $Root 'install.json'
$StartupDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
$StartupVbs = Join-Path $StartupDir 'HAPCAPEX-SAP-Bridge.vbs'

function Write-Step {
    param([int]$Number,[string]$Text)
    if (-not $Silent) { Write-Host ('[{0}/7] {1}' -f $Number,$Text) -ForegroundColor Cyan }
}

function Write-InstallLog {
    param([Parameter(Mandatory=$true)][string]$Text,[string]$Level='INFO')
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Text
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
    if (-not $Silent) { Write-Host $Text }
}

function Get-InteractiveUserIdentity {
    try {
        $interactiveName = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName
        if ([string]::IsNullOrWhiteSpace($interactiveName)) { return $null }
        $account = New-Object Security.Principal.NTAccount($interactiveName)
        $sid = $account.Translate([Security.Principal.SecurityIdentifier])
        return [pscustomobject]@{Name=$interactiveName;Sid=$sid.Value}
    } catch { return $null }
}

function Assert-SameInteractiveUser {
    try {
        $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
        $currentSid=$identity.User.Value
        $currentName=$identity.Name
        $principal=New-Object Security.Principal.WindowsPrincipal($identity)
        $isElevated=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        $currentSid=''; $currentName=[Environment]::UserName; $isElevated=$false
    }
    $interactive=Get-InteractiveUserIdentity
    if ($interactive -and $currentSid -and ($interactive.Sid -ne $currentSid)) {
        throw ('O instalador está usando outra conta. Instalador: {0}; usuário interativo: {1}.' -f $currentName,$interactive.Name)
    }
    if (-not $Silent) {
        Write-Host ('Usuário da instalação: {0}' -f $currentName)
        if ($interactive) { Write-Host ('Usuário interativo: {0}' -f $interactive.Name) }
        Write-Host ('Execução elevada: {0}' -f $(if($isElevated){'SIM - mesmo usuário, permitido'}else{'NÃO'}))
        Write-Host ('Pasta de destino: {0}' -f $Root)
        Write-Host ''
    }
}

function Test-TargetWritable {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $probe=Join-Path $Root ('.hapcapex-write-test-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        'HAPCAPEX' | Set-Content -LiteralPath $probe -Encoding ASCII
        $read=[string](Get-Content -LiteralPath $probe -Raw -ErrorAction Stop)
        if ($read.Trim() -ne 'HAPCAPEX') { throw 'Falha ao validar leitura do arquivo de teste.' }
    } finally { Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue }
}

function Get-BridgeHealth {
    try { return Invoke-RestMethod -Uri ('http://127.0.0.1:{0}/api/health' -f $Port) -Method Get -TimeoutSec 1 }
    catch { return $null }
}

function Stop-InstalledBridge {
    # Evita consultar a tabela TCP via cmdlet de rede: em algumas estações corporativas
    # essa consulta pode bloquear por vários minutos. O Bridge mantém seu próprio PID no perfil.
    if (Test-Path -LiteralPath $PidPath) {
        try {
            $oldPid=[int](Get-Content -LiteralPath $PidPath -Raw -ErrorAction Stop)
            $proc=Get-Process -Id $oldPid -ErrorAction SilentlyContinue
            if ($proc) {
                Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
                try { $proc.WaitForExit(3000) | Out-Null } catch {}
            }
        } catch {}
    }
    Remove-Item -LiteralPath $PidPath -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 350
}

function Start-InstalledBridge {
    $psExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $psi=New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName=$psExe
    $psi.Arguments=('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "{0}"' -f $BridgePath)
    $psi.UseShellExecute=$false
    $psi.CreateNoWindow=$true
    $psi.WindowStyle=[System.Diagnostics.ProcessWindowStyle]::Hidden
    $p=[System.Diagnostics.Process]::Start($psi)
    if ($null -eq $p) { throw 'O processo local do Bridge não pôde ser iniciado.' }
}

function Wait-BridgeHealth {
    param([string]$Version,[int]$Seconds=25)
    $deadline=(Get-Date).AddSeconds($Seconds)
    do {
        Start-Sleep -Milliseconds 400
        $health=Get-BridgeHealth
        if ($health -and $health.ok -and ([string]$health.version -eq $Version)) { return $health }
    } while ((Get-Date) -lt $deadline)
    return $null
}

function Test-ProtocolRegistration {
    param([string]$SilentLauncherPath)
    try {
        $root='HKCU:\Software\Classes\hapcapex-sap'
        $cmdKey=Join-Path $root 'shell\open\command'
        if (-not (Test-Path -LiteralPath $cmdKey)) { return $false }
        [void](Get-ItemProperty -LiteralPath $root -Name 'URL Protocol' -ErrorAction Stop)
        $command=[string](Get-Item -LiteralPath $cmdKey).GetValue('')
        return ($command -and $command.IndexOf($SilentLauncherPath,[System.StringComparison]::OrdinalIgnoreCase) -ge 0)
    } catch { return $false }
}

function Set-ProtocolAndAutostart {
    param([string]$SilentLauncherPath)
    $wscript=Join-Path $env:SystemRoot 'System32\wscript.exe'
    $protocolRoot='HKCU:\Software\Classes\hapcapex-sap'
    $commandKey=Join-Path $protocolRoot 'shell\open\command'
    $protocolCommand='"' + $wscript + '" //B //Nologo "' + $SilentLauncherPath + '" "%1"'

    New-Item -Path $protocolRoot -Force | Out-Null
    Set-Item -Path $protocolRoot -Value 'URL:HAPCAPEX SAP Bridge Protocol'
    Set-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value ''
    New-Item -Path $commandKey -Force | Out-Null
    Set-Item -Path $commandKey -Value $protocolCommand
    if (-not (Test-ProtocolRegistration -SilentLauncherPath $SilentLauncherPath)) {
        throw 'O registro do protocolo hapcapex-sap:// não pôde ser validado.'
    }

    $runKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    New-Item -Path $runKey -Force | Out-Null
    $auto='"' + $wscript + '" //B //Nologo "' + $SilentLauncherPath + '" "hapcapex-sap://start"'
    Set-ItemProperty -Path $runKey -Name 'HAPCAPEX SAP Bridge' -Value $auto

    # Segunda forma de inicialização: pasta Startup do MESMO usuário.
    # O VBS é silencioso e, sem argumento, inicia o Bridge.
    New-Item -ItemType Directory -Path $StartupDir -Force | Out-Null
    Copy-Item -LiteralPath $SilentLauncherPath -Destination $StartupVbs -Force
    if (-not (Test-Path -LiteralPath $StartupVbs)) { throw 'Falha ao criar o fallback de inicialização na pasta Startup.' }
}

function Verify-CopiedFiles {
    param([string[]]$Names)
    foreach ($name in $Names) {
        $src=Join-Path $SourceDir $name
        $dst=Join-Path $Root $name
        if (-not (Test-Path -LiteralPath $dst)) { throw ('Arquivo não copiado: {0}' -f $name) }
        $a=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
        $b=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
        if ($a -ne $b) { throw ('Hash divergente após copiar: {0}' -f $name) }
    }
}

function Restore-PreviousInstallation {
    param([string]$BackupPath)
    if (-not $BackupPath -or -not (Test-Path -LiteralPath $BackupPath)) { return }
    Get-ChildItem -LiteralPath $Root -File -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Name -notin @('installer.log')) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    }
    Get-ChildItem -LiteralPath $BackupPath -File | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $Root $_.Name) -Force
    }
}

$RequiredFiles=@(
    'HAPCAPEX-SAP-Bridge.ps1',
    'HAPCAPEX-SAP-MacroBridge.vbs',
    'HAPCAPEX-SAP-Launcher.ps1',
    'HAPCAPEX-SAP-SilentLauncher.vbs',
    'Reparar-HAPCAPEX-SAP-Bridge.ps1',
    'REPARAR-PROTOCOLO-AGORA.cmd',
    'Atualizar-HAPCAPEX-SAP-Bridge.ps1',
    'Atualizar-HAPCAPEX-SAP-Bridge.cmd',
    'Diagnostico-MacroBridge.cmd',
    'Detectar-HAPCAPEX-SAP-Bridge.ps1',
    'Desinstalar-HAPCAPEX-SAP-Bridge.ps1',
    'Desinstalar-HAPCAPEX-SAP-Bridge.cmd'
)

$backupPath=''
try {
    Assert-SameInteractiveUser

    Write-Step 1 'Validando o pacote...'
    foreach ($name in $RequiredFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $SourceDir $name))) { throw ('Arquivo obrigatório ausente: {0}' -f $name) }
    }

    Write-Step 2 'Validando a pasta de destino...'
    Test-TargetWritable
    New-Item -ItemType Directory -Path (Join-Path $Root 'exports') -Force | Out-Null
    New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
    Write-InstallLog -Text 'Pasta de destino validada para leitura e gravação.'

    Write-Step 3 'Preservando a instalação anterior e encerrando o Bridge...'
    if (Test-Path -LiteralPath $BridgePath) {
        $backupPath=Join-Path $BackupRoot (Get-Date -Format 'yyyyMMdd_HHmmss')
        New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
        foreach ($name in ($RequiredFiles + @('config.json','install.json'))) {
            $old=Join-Path $Root $name
            if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination (Join-Path $backupPath $name) -Force }
        }
    }
    Stop-InstalledBridge
    $still=Get-BridgeHealth
    if ($still -and $still.ok) {
        throw ('Já existe um Bridge respondendo na porta {0} e ele não pôde ser encerrado com segurança. Feche-o e tente novamente.' -f $Port)
    }

    Write-Step 4 'Copiando e verificando os arquivos...'
    foreach ($name in $RequiredFiles) {
        Copy-Item -LiteralPath (Join-Path $SourceDir $name) -Destination (Join-Path $Root $name) -Force
    }
    $configExample=Join-Path $SourceDir 'config.example.json'
    $configPath=Join-Path $Root 'config.json'
    if ((Test-Path -LiteralPath $configExample) -and -not (Test-Path -LiteralPath $configPath)) {
        Copy-Item -LiteralPath $configExample -Destination $configPath -Force
    }
    Verify-CopiedFiles -Names $RequiredFiles
    Write-InstallLog -Text 'Arquivos copiados e hashes verificados.'

    Write-Step 5 'Registrando o protocolo e a inicialização automática...'
    $silentLauncher=Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs'
    Set-ProtocolAndAutostart -SilentLauncherPath $silentLauncher
    Write-InstallLog -Text 'Protocolo e duas formas de autostart registrados e validados.'

    $installInfo=[ordered]@{
        product='HAPCAPEX SAP Bridge'; version=$ExpectedVersion; distribution='corporate';
        distributionVersion=$DistributionVersion; installedAt=(Get-Date).ToString('o');
        installedBy=[Environment]::UserName; machineName=[Environment]::MachineName;
        source=$Source; installScope='CurrentUser'; autoStart=$true; startupFallback=$true
    }
    $installInfo | ConvertTo-Json | Set-Content -LiteralPath $InstallJsonPath -Encoding UTF8

    Write-Step 6 'Iniciando o SAP Bridge...'
    if (-not $NoStart) {
        Start-InstalledBridge
        $health=Wait-BridgeHealth -Version $ExpectedVersion -Seconds 25
        if ($null -eq $health) {
            $tail=''
            $bridgeLog=Join-Path $Root 'bridge.log'
            if (Test-Path -LiteralPath $bridgeLog) {
                try { $tail=((Get-Content -LiteralPath $bridgeLog -Tail 6) -join ' | ') } catch {}
            }
            throw ('O Bridge foi copiado, mas não respondeu em até 25 s. {0}' -f $tail)
        }
    }

    Write-Step 7 'Validando a instalação final...'
    if (-not (Test-ProtocolRegistration -SilentLauncherPath $silentLauncher)) { throw 'Validação final do protocolo falhou.' }
    if (-not (Test-Path -LiteralPath $StartupVbs)) { throw 'Validação final do fallback de Startup falhou.' }
    Write-InstallLog -Text ('Bridge {0} / distribuição {1} instalado com sucesso.' -f $ExpectedVersion,$DistributionVersion)

    if (-not $Silent) {
        Write-Host ''
        Write-Host 'INSTALAÇÃO CONCLUÍDA COM SUCESSO.' -ForegroundColor Green
        Write-Host ('Versão: {0}' -f $ExpectedVersion) -ForegroundColor Cyan
        Write-Host ('Pasta: {0}' -f $Root)
        Write-Host 'Protocolo hapcapex-sap://: OK'
        Write-Host 'Autostart: Run + Startup: OK'
        Write-Host ''
        Read-Host 'ENTER para fechar' | Out-Null
    }
    exit 0
} catch {
    $message=$_.Exception.Message
    try { Write-InstallLog -Text ('Falha: {0}' -f $message) -Level 'ERROR' } catch {}
    Stop-InstalledBridge
    if ($backupPath) {
        try {
            Restore-PreviousInstallation -BackupPath $backupPath
            if (Test-Path -LiteralPath (Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs')) {
                Set-ProtocolAndAutostart -SilentLauncherPath (Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs')
            }
            if (Test-Path -LiteralPath $BridgePath) { Start-InstalledBridge }
            Write-InstallLog -Text 'Rollback local concluído e versão anterior reiniciada.' -Level 'WARN'
        } catch {}
    }
    if (-not $Silent) {
        Write-Host ''
        Write-Host 'A instalação não foi concluída.' -ForegroundColor Red
        Write-Host $message -ForegroundColor Yellow
        Write-Host ('Log: {0}' -f $LogPath)
        Read-Host 'ENTER para fechar' | Out-Null
    }
    exit 20
}
