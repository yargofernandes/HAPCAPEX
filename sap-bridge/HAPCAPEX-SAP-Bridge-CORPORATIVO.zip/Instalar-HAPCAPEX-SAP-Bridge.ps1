﻿param(
    [switch]$Silent,
    [switch]$NoStart,
    [string]$Source = 'manual'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ExpectedVersion = '1.1.4-alpha'
$DistributionVersion = '1.0.6'
$Port = 17891
$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$BackupRoot = Join-Path $Root 'rollback'
$LogPath = Join-Path $Root 'installer.log'
$PidPath = Join-Path $Root 'bridge.pid'
$BridgePath = Join-Path $Root 'HAPCAPEX-SAP-Bridge.ps1'
$InstallJsonPath = Join-Path $Root 'install.json'

function Write-InstallLog {
    param(
        [Parameter(Mandatory=$true)][string]$Text,
        [string]$Level = 'INFO'
    )

    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Text
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
    if (-not $Silent) {
        Write-Host $Text
    }
}

function Stop-InstalledBridge {
    if (Test-Path -LiteralPath $PidPath) {
        try {
            $oldPid = [int](Get-Content -LiteralPath $PidPath -Raw -ErrorAction Stop)
            $proc = Get-Process -Id $oldPid -ErrorAction SilentlyContinue
            if ($proc) {
                Stop-Process -Id $oldPid -Force -ErrorAction SilentlyContinue
            }
        } catch {}
    }

    try {
        $listener = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($listener) {
            $ownerPid = [int]$listener.OwningProcess
            $commandLine = ''
            try {
                $commandLine = [string](Get-CimInstance Win32_Process -Filter ('ProcessId={0}' -f $ownerPid)).CommandLine
            } catch {}

            if ($commandLine -match 'HAPCAPEX-SAP-Bridge\.ps1') {
                Stop-Process -Id $ownerPid -Force -ErrorAction SilentlyContinue
            }
        }
    } catch {}

    Remove-Item -LiteralPath $PidPath -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 400
}

function Start-InstalledBridge {
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $psExe
    $psi.Arguments = ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "{0}"' -f $BridgePath)
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
    [void][System.Diagnostics.Process]::Start($psi)
}

function Wait-BridgeHealth {
    param(
        [Parameter(Mandatory=$true)][string]$Version,
        [int]$Seconds = 15
    )

    $deadline = (Get-Date).AddSeconds($Seconds)
    do {
        Start-Sleep -Milliseconds 300
        try {
            $health = Invoke-RestMethod -Uri ('http://127.0.0.1:{0}/api/health' -f $Port) -Method Get -TimeoutSec 1
            if ($health.ok -and ([string]$health.version -eq $Version)) {
                return $true
            }
        } catch {}
    } while ((Get-Date) -lt $deadline)

    return $false
}

function Set-LegacyProtocol {
    param([string]$TargetBridgePath)

    $protocolRoot = 'HKCU:\Software\Classes\hapcapex-sap'
    New-Item -Path $protocolRoot -Force | Out-Null
    Set-Item -Path $protocolRoot -Value 'URL:HAPCAPEX SAP Bridge Protocol'
    Set-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value ''

    $commandKey = Join-Path $protocolRoot 'shell\open\command'
    New-Item -Path $commandKey -Force | Out-Null
    $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $TargetBridgePath + '" -Protocol "%1"'
    Set-Item -Path $commandKey -Value $command
}

function Restore-PreviousInstallation {
    param(
        [string]$BackupPath,
        [string]$PreviousDistribution
    )

    if ([string]::IsNullOrWhiteSpace($BackupPath) -or -not (Test-Path -LiteralPath $BackupPath)) {
        return
    }

    Write-InstallLog -Text 'Restaurando a versão anterior...' -Level 'WARN'

    Get-ChildItem -LiteralPath $Root -File -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Name -notin @('installer.log')) {
            Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
        }
    }

    Get-ChildItem -LiteralPath $BackupPath -File -ErrorAction Stop | ForEach-Object {
        $destination = Join-Path $Root $_.Name
        Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
    }

    if ($PreviousDistribution -eq 'corporate') {
        # The restored corporate package already contains the launcher/updater.
        $launcher = Join-Path $Root 'HAPCAPEX-SAP-Launcher.ps1'
        if (Test-Path -LiteralPath $launcher) {
            $protocolRoot = 'HKCU:\Software\Classes\hapcapex-sap'
            New-Item -Path $protocolRoot -Force | Out-Null
            Set-Item -Path $protocolRoot -Value 'URL:HAPCAPEX SAP Bridge Protocol'
            Set-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value ''
            $commandKey = Join-Path $protocolRoot 'shell\open\command'
            New-Item -Path $commandKey -Force | Out-Null
            $command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $launcher + '" -Protocol "%1"'
            Set-Item -Path $commandKey -Value $command
        }
    } else {
        Set-LegacyProtocol -TargetBridgePath $BridgePath
        Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HAPCAPEX SAP Bridge' -Force -ErrorAction SilentlyContinue
    }

    try {
        $previousVersion = ''
        if (Test-Path -LiteralPath $InstallJsonPath) {
            $previousVersion = [string]((Get-Content -LiteralPath $InstallJsonPath -Raw | ConvertFrom-Json).version)
        }
        Start-InstalledBridge
        if ($previousVersion) {
            [void](Wait-BridgeHealth -Version $previousVersion -Seconds 8)
        }
    } catch {}
}

$RequiredFiles = @(
    'HAPCAPEX-SAP-Bridge.ps1',
    'HAPCAPEX-SAP-MacroBridge.vbs',
    'HAPCAPEX-SAP-Launcher.ps1',
    'HAPCAPEX-SAP-SilentLauncher.vbs',
    'Atualizar-HAPCAPEX-SAP-Bridge.ps1',
    'Atualizar-HAPCAPEX-SAP-Bridge.cmd',
    'Diagnostico-MacroBridge.cmd',
    'Detectar-HAPCAPEX-SAP-Bridge.ps1',
    'Desinstalar-HAPCAPEX-SAP-Bridge.ps1',
    'Desinstalar-HAPCAPEX-SAP-Bridge.cmd'
)

foreach ($name in $RequiredFiles) {
    $sourcePath = Join-Path $SourceDir $name
    if (-not (Test-Path -LiteralPath $sourcePath)) {
        Write-InstallLog -Text ('Arquivo obrigatório ausente: {0}' -f $name) -Level 'ERROR'
        exit 10
    }
}

New-Item -ItemType Directory -Path $Root -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Root 'exports') -Force | Out-Null
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null

$backupPath = ''
$previousVersion = ''
$previousDistribution = ''

if (Test-Path -LiteralPath $InstallJsonPath) {
    try {
        $previousInstall = Get-Content -LiteralPath $InstallJsonPath -Raw | ConvertFrom-Json
        $previousVersion = [string]$previousInstall.version
        $previousDistribution = [string]$previousInstall.distribution
    } catch {}
}

if (-not $previousVersion) {
    try {
        $health = Invoke-RestMethod -Uri ('http://127.0.0.1:{0}/api/health' -f $Port) -Method Get -TimeoutSec 1
        $previousVersion = [string]$health.version
        if ($health.PSObject.Properties.Name -contains 'distribution') {
            $previousDistribution = [string]$health.distribution
        }
    } catch {}
}

if (Test-Path -LiteralPath $BridgePath) {
    $backupPath = Join-Path $BackupRoot (Get-Date -Format 'yyyyMMdd_HHmmss')
    New-Item -ItemType Directory -Path $backupPath -Force | Out-Null

    $filesToBackup = $RequiredFiles + @('config.json', 'install.json')
    foreach ($name in $filesToBackup) {
        $existingPath = Join-Path $Root $name
        if (Test-Path -LiteralPath $existingPath) {
            $backupDestination = Join-Path $backupPath $name
            Copy-Item -LiteralPath $existingPath -Destination $backupDestination -Force
        }
    }
}

Stop-InstalledBridge

try {
    foreach ($name in $RequiredFiles) {
        $sourcePath = Join-Path $SourceDir $name
        $destinationPath = Join-Path $Root $name
        Copy-Item -LiteralPath $sourcePath -Destination $destinationPath -Force
    }

    $configExample = Join-Path $SourceDir 'config.example.json'
    $configPath = Join-Path $Root 'config.json'
    if ((Test-Path -LiteralPath $configExample) -and -not (Test-Path -LiteralPath $configPath)) {
        Copy-Item -LiteralPath $configExample -Destination $configPath -Force
    }

    $launcherPath = Join-Path $Root 'HAPCAPEX-SAP-Launcher.ps1'
    $silentLauncherPath = Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs'
    $updaterPath = Join-Path $Root 'Atualizar-HAPCAPEX-SAP-Bridge.ps1'
    $wscriptPath = Join-Path $env:SystemRoot 'System32\wscript.exe'

    $protocolRoot = 'HKCU:\Software\Classes\hapcapex-sap'
    New-Item -Path $protocolRoot -Force | Out-Null
    Set-Item -Path $protocolRoot -Value 'URL:HAPCAPEX SAP Bridge Protocol'
    Set-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value ''

    $commandKey = Join-Path $protocolRoot 'shell\open\command'
    New-Item -Path $commandKey -Force | Out-Null
    $protocolCommand = '"' + $wscriptPath + '" //B //Nologo "' + $silentLauncherPath + '" "%1"'
    Set-Item -Path $commandKey -Value $protocolCommand

    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    New-Item -Path $runKey -Force | Out-Null
    $autoStartCommand = '"' + $wscriptPath + '" //B //Nologo "' + $silentLauncherPath + '" "hapcapex-sap://start"'
    Set-ItemProperty -Path $runKey -Name 'HAPCAPEX SAP Bridge' -Value $autoStartCommand

    $startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\HAPCAPEX'
    New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
    $wsh = New-Object -ComObject WScript.Shell

    $bridgeShortcut = $wsh.CreateShortcut((Join-Path $startMenu 'HAPCAPEX SAP Bridge.lnk'))
    $bridgeShortcut.TargetPath = $wscriptPath
    $bridgeShortcut.Arguments = '//B //Nologo "' + $silentLauncherPath + '" "hapcapex-sap://start"'
    $bridgeShortcut.WorkingDirectory = $Root
    $bridgeShortcut.Description = 'HAPCAPEX SAP Bridge'
    $bridgeShortcut.Save()

    $updateShortcut = $wsh.CreateShortcut((Join-Path $startMenu 'Atualizar SAP Bridge.lnk'))
    $updateShortcut.TargetPath = $wscriptPath
    $updateShortcut.Arguments = '//B //Nologo "' + $silentLauncherPath + '" "hapcapex-sap://update"'
    $updateShortcut.WorkingDirectory = $Root
    $updateShortcut.Description = 'Atualizar HAPCAPEX SAP Bridge'
    $updateShortcut.Save()

    $installInfo = [ordered]@{
        product = 'HAPCAPEX SAP Bridge'
        version = $ExpectedVersion
        distribution = 'corporate'
        distributionVersion = $DistributionVersion
        installedAt = (Get-Date).ToString('o')
        installedBy = [Environment]::UserName
        machineName = [Environment]::MachineName
        source = $Source
        previousVersion = $previousVersion
        installScope = 'CurrentUser'
        autoStart = $true
    }
    $installInfo | ConvertTo-Json | Set-Content -LiteralPath $InstallJsonPath -Encoding UTF8

    if (-not $NoStart) {
        Start-InstalledBridge
        if (-not (Wait-BridgeHealth -Version $ExpectedVersion -Seconds 15)) {
            throw ('O Bridge {0} foi instalado, mas não respondeu na porta {1}.' -f $ExpectedVersion, $Port)
        }
    }

    Write-InstallLog -Text ('Bridge {0} instalado/atualizado com sucesso.' -f $ExpectedVersion)

    if (-not $Silent) {
        Write-Host ''
        Write-Host 'Instalação corporativa concluída.' -ForegroundColor Green
        Write-Host ('Versão: {0}' -f $ExpectedVersion) -ForegroundColor Cyan
        Write-Host ('Pasta: {0}' -f $Root)
        Write-Host 'O Bridge iniciará automaticamente quando este usuário entrar no Windows.'
        Write-Host ''
        Read-Host 'ENTER para fechar' | Out-Null
    }

    exit 0
} catch {
    $message = $_.Exception.Message
    Write-InstallLog -Text ('Falha: {0}' -f $message) -Level 'ERROR'
    Stop-InstalledBridge

    if ($backupPath) {
        try {
            Restore-PreviousInstallation -BackupPath $backupPath -PreviousDistribution $previousDistribution
            Write-InstallLog -Text ('Rollback concluído para a versão anterior: {0}' -f $previousVersion) -Level 'WARN'
        } catch {
            Write-InstallLog -Text ('Falha também no rollback: {0}' -f $_.Exception.Message) -Level 'ERROR'
        }
    }

    if (-not $Silent) {
        Write-Host ''
        Write-Host 'A instalação não foi concluída.' -ForegroundColor Red
        Write-Host $message -ForegroundColor Yellow
        if ($backupPath) {
            Write-Host 'A versão anterior foi preservada/restaurada quando possível.'
        }
        Write-Host ('Log: {0}' -f $LogPath)
        Read-Host 'ENTER para fechar' | Out-Null
    }

    exit 20
}
