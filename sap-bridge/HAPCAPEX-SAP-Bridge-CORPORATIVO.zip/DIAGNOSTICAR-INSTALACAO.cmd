@echo off
title HAPCAPEX SAP Bridge - DIAGNOSTICO
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnosticar-Instalacao.ps1"
