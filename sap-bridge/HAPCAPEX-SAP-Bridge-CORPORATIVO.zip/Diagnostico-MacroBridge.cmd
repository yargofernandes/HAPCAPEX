@echo off
setlocal
set "HELPER=%~dp0HAPCAPEX-SAP-MacroBridge.vbs"
if not exist "%HELPER%" (
  set "HELPER=%LOCALAPPDATA%\HAPCAPEX\SapBridge\HAPCAPEX-SAP-MacroBridge.vbs"
)
echo === HAPCAPEX MacroBridge - diagnostico V1.0.6 ===
echo Helper: %HELPER%
echo.
if not exist "%HELPER%" (
  echo ERRO: HAPCAPEX-SAP-MacroBridge.vbs nao foi encontrado.
  pause
  exit /b 2
)

echo Tentando cscript 32 bits...
if exist "%WINDIR%\SysWOW64\cscript.exe" "%WINDIR%\SysWOW64\cscript.exe" //NoLogo "%HELPER%" probe
echo.
echo Tentando cscript 64 bits...
"%WINDIR%\System32\cscript.exe" //NoLogo "%HELPER%" probe
echo.
pause
