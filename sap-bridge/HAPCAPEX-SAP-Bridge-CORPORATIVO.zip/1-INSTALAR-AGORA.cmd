@echo off
setlocal
title HAPCAPEX SAP Bridge - INSTALACAO 1.1.7-alpha RC4
echo.
echo HAPCAPEX SAP Bridge - Instalacao 1.1.7-alpha RC4
echo O instalador mostrara 7 etapas e nao deve ficar silencioso.
echo.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-HAPCAPEX-SAP-Bridge.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
