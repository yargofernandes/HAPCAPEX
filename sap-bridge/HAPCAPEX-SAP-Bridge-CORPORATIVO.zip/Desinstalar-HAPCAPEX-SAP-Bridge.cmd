@echo off
setlocal
title HAPCAPEX SAP Bridge - Desinstalacao
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Desinstalar-HAPCAPEX-SAP-Bridge.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
