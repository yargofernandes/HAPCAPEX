@echo off
setlocal
title HAPCAPEX SAP Bridge - REPARAR PROTOCOLO
echo.
echo HAPCAPEX SAP Bridge - Reparar protocolo hapcapex-sap://
echo Execute com DUPLO CLIQUE NORMAL. Nao use "Executar como administrador".
echo.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Reparar-HAPCAPEX-SAP-Bridge.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
