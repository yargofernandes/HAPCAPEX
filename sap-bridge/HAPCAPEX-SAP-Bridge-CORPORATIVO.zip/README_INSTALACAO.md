﻿# HAPCAPEX SAP Bridge Corporativo — V1.1.7-alpha (pacote 1.0.11)

## Instalação piloto
1. Extraia TODO o conteúdo do ZIP para uma pasta local.
2. Execute `Instalar-HAPCAPEX-SAP-Bridge.cmd`.
3. Aguarde a mensagem `Instalação corporativa concluída`.
4. Abra HAPCAPEX > Base Consumo > Atualizar pelo SAP.
5. O topo deve mostrar `Bridge 1.1.7-alpha`.

Não desinstale a versão anterior antes. O instalador faz backup e tenta restaurá-la se a nova versão não responder.

Este pacote 1.0.11 amplia a tolerância das extrações SAP longas: Helper até 15 minutos e geração do XLSX até 10 minutos.


SEGURANÇA 1.1.6
- Endpoints SAP exigem pareamento temporário com sessão autenticada do HAPCAPEX.
- Token local existe apenas na memória e expira.
- Senha SAP não é lida nem armazenada.


## Execução elevada em estações corporativas
Se o Windows abrir o .cmd com título **Administrador** mesmo após duplo clique normal, o instalador compara a conta elevada com o usuário interativo. Se forem a mesma conta, a instalação CurrentUser é permitida. Se forem contas diferentes, a instalação é bloqueada para evitar registrar protocolo/autostart no perfil errado.
