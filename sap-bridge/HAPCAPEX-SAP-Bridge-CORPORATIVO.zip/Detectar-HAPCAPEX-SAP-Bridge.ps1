﻿param(
    [string]$ExpectedVersion = '1.1.4-alpha',
    [string]$ExpectedDistributionVersion = '1.0.6'
)

$ErrorActionPreference = 'SilentlyContinue'
$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$InstallJsonPath = Join-Path $Root 'install.json'

$required = @(
    'HAPCAPEX-SAP-Bridge.ps1',
    'HAPCAPEX-SAP-MacroBridge.vbs',
    'HAPCAPEX-SAP-Launcher.ps1',
    'Atualizar-HAPCAPEX-SAP-Bridge.ps1',
    'install.json'
)

foreach ($name in $required) {
    $path = Join-Path $Root $name
    if (-not (Test-Path -LiteralPath $path)) {
        Write-Output ('MISSING:{0}' -f $name)
        exit 1
    }
}

try {
    $install = Get-Content -LiteralPath $InstallJsonPath -Raw | ConvertFrom-Json
    $version = [string]$install.version
    $distributionVersion = [string]$install.distributionVersion
} catch {
    Write-Output 'INSTALLJSON:INVALID'
    exit 1
}

if ($version -ne $ExpectedVersion) {
    Write-Output ('VERSION:{0}' -f $version)
    exit 1
}

if ($ExpectedDistributionVersion -and ($distributionVersion -ne $ExpectedDistributionVersion)) {
    Write-Output ('DISTRIBUTION:{0}' -f $distributionVersion)
    exit 1
}

$autoStart = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HAPCAPEX SAP Bridge' -ErrorAction SilentlyContinue
if (-not $autoStart) {
    Write-Output 'AUTOSTART:MISSING'
    exit 1
}

Write-Output ('HAPCAPEX SAP Bridge {0} pacote {1} instalado' -f $version, $distributionVersion)
exit 0
