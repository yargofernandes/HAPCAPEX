﻿$ErrorActionPreference='SilentlyContinue'
$Root=Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$Silent=Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs'
$Startup=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\HAPCAPEX-SAP-Bridge.vbs'
Write-Host '=== HAPCAPEX SAP Bridge - Diagnóstico ===' -ForegroundColor Cyan
Write-Host ('Usuário: '+[Security.Principal.WindowsIdentity]::GetCurrent().Name)
Write-Host ('Destino: '+$Root)
Write-Host ('Pasta existe: '+(Test-Path $Root))
Write-Host ('Bridge existe: '+(Test-Path (Join-Path $Root 'HAPCAPEX-SAP-Bridge.ps1')))
Write-Host ('Silent launcher existe: '+(Test-Path $Silent))
Write-Host ('Fallback Startup existe: '+(Test-Path $Startup))
try{$cmd=[string](Get-Item 'HKCU:\Software\Classes\hapcapex-sap\shell\open\command').GetValue('');Write-Host ('Protocolo: '+$cmd)}catch{Write-Host 'Protocolo: AUSENTE' -ForegroundColor Yellow}
try{$run=(Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run').'HAPCAPEX SAP Bridge';Write-Host ('Run: '+$run)}catch{Write-Host 'Run: AUSENTE' -ForegroundColor Yellow}
try{$h=Invoke-RestMethod 'http://127.0.0.1:17891/api/health' -TimeoutSec 2;Write-Host ('Health: OK '+$h.version+' / '+$h.distributionVersion) -ForegroundColor Green}catch{Write-Host 'Health: OFFLINE' -ForegroundColor Yellow}
Write-Host ''
Read-Host 'ENTER para fechar'|Out-Null
