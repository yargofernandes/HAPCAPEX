﻿param([switch]$Silent)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$Root=Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$Bridge=Join-Path $Root 'HAPCAPEX-SAP-Bridge.ps1'
$SilentLauncher=Join-Path $Root 'HAPCAPEX-SAP-SilentLauncher.vbs'
$Startup=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\HAPCAPEX-SAP-Bridge.vbs'
if(-not(Test-Path -LiteralPath $Bridge)-or-not(Test-Path -LiteralPath $SilentLauncher)){throw ('Instalação não encontrada em '+$Root)}
$wscript=Join-Path $env:SystemRoot 'System32\wscript.exe'
$proto='HKCU:\Software\Classes\hapcapex-sap';$cmdKey=Join-Path $proto 'shell\open\command'
New-Item -Path $proto -Force|Out-Null;Set-Item -Path $proto -Value 'URL:HAPCAPEX SAP Bridge Protocol';Set-ItemProperty -Path $proto -Name 'URL Protocol' -Value ''
New-Item -Path $cmdKey -Force|Out-Null;Set-Item -Path $cmdKey -Value ('"'+$wscript+'" //B //Nologo "'+$SilentLauncher+'" "%1"')
$run='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run';New-Item -Path $run -Force|Out-Null;Set-ItemProperty -Path $run -Name 'HAPCAPEX SAP Bridge' -Value ('"'+$wscript+'" //B //Nologo "'+$SilentLauncher+'" "hapcapex-sap://start"')
New-Item -ItemType Directory -Path (Split-Path -Parent $Startup) -Force|Out-Null;Copy-Item -LiteralPath $SilentLauncher -Destination $Startup -Force
& $wscript //B //Nologo $SilentLauncher 'hapcapex-sap://start'
if(-not $Silent){Write-Host 'Protocolo e autostart reparados.' -ForegroundColor Green;Read-Host 'ENTER para fechar'|Out-Null}
