@echo off
setlocal
title HAPCAPEX SAP Bridge - INSTALACAO PILOTO
echo.
echo HAPCAPEX SAP Bridge - Instalacao piloto corrigida
echo Execute este arquivo com DUPLO CLIQUE NORMAL.
echo Nao use Atualizar-HAPCAPEX-SAP-Bridge.cmd neste primeiro teste.
echo.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-HAPCAPEX-SAP-Bridge.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
