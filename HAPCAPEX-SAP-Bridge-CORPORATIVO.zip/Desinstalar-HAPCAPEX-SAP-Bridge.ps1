﻿param(
    [switch]$Silent,
    [switch]$KeepLogs
)

$ErrorActionPreference = 'SilentlyContinue'
$Root = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$PidPath = Join-Path $Root 'bridge.pid'

if (Test-Path -LiteralPath $PidPath) {
    try {
        $bridgePid = [int](Get-Content -LiteralPath $PidPath -Raw)
        Stop-Process -Id $bridgePid -Force -ErrorAction SilentlyContinue
    } catch {}
}

try {
    $listener = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 17891 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        $ownerPid = [int]$listener.OwningProcess
        $commandLine = [string](Get-CimInstance Win32_Process -Filter ('ProcessId={0}' -f $ownerPid)).CommandLine
        if ($commandLine -match 'HAPCAPEX-SAP-Bridge\.ps1') {
            Stop-Process -Id $ownerPid -Force -ErrorAction SilentlyContinue
        }
    }
} catch {}

Remove-Item -Path 'HKCU:\Software\Classes\hapcapex-sap' -Recurse -Force -ErrorAction SilentlyContinue
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'HAPCAPEX SAP Bridge' -Force -ErrorAction SilentlyContinue

$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\HAPCAPEX'
Remove-Item -LiteralPath (Join-Path $startMenu 'HAPCAPEX SAP Bridge.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $startMenu 'Atualizar SAP Bridge.lnk') -Force -ErrorAction SilentlyContinue

if ($KeepLogs) {
    if (Test-Path -LiteralPath $Root) {
        Get-ChildItem -LiteralPath $Root -Force | Where-Object { $_.Name -notmatch '\.log$' } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
} else {
    Remove-Item -LiteralPath $Root -Recurse -Force -ErrorAction SilentlyContinue
}

if (-not $Silent) {
    Write-Host 'HAPCAPEX SAP Bridge removido.' -ForegroundColor Green
}

exit 0
