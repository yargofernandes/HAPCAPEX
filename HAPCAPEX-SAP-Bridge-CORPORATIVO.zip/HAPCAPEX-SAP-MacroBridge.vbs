Option Explicit

Dim action, param1, param2, param3, result
If WScript.Arguments.Count < 1 Then
  WScript.Echo "ERR|ARGUMENTS|init|Acao nao informada"
  WScript.Quit 2
End If

action = LCase(WScript.Arguments(0))
param1 = ""
param2 = ""
param3 = ""

If WScript.Arguments.Count >= 2 Then param1 = CStr(WScript.Arguments(1))
If WScript.Arguments.Count >= 3 Then param2 = CStr(WScript.Arguments(2))
If WScript.Arguments.Count >= 4 Then param3 = CStr(WScript.Arguments(3))

Function CleanField(v)
  On Error Resume Next
  If IsNull(v) Or IsEmpty(v) Then
    CleanField = ""
  Else
    CleanField = Replace(Replace(Replace(CStr(v), "|", "/"), vbCr, " "), vbLf, " ")
  End If
  On Error GoTo 0
End Function

Sub Fail(code, stepName, message)
  WScript.Echo "ERR|" & CleanField(code) & "|" & CleanField(stepName) & "|" & CleanField(message)
  WScript.Quit 3
End Sub

Function GetSapApplication()
  Dim SapGuiAuto, SapApp
  On Error Resume Next

  Err.Clear
  Set SapGuiAuto = GetObject("SAPGUI")
  If Err.Number <> 0 Or SapGuiAuto Is Nothing Then
    Fail "SAP_GETOBJECT_FAILED", "getobject", "GetObject(SAPGUI) falhou: " & Err.Description
  End If

  Err.Clear
  Set SapApp = SapGuiAuto.GetScriptingEngine
  If Err.Number <> 0 Or SapApp Is Nothing Then
    Fail "SAP_SCRIPTING_ENGINE_FAILED", "scripting", "Nao foi possivel obter GetScriptingEngine: " & Err.Description
  End If

  On Error GoTo 0
  Set GetSapApplication = SapApp
End Function

Function CollectionElementAt(collectionObj, indexValue)
  Dim idx, obj
  Set CollectionElementAt = Nothing
  If collectionObj Is Nothing Then Exit Function
  idx = CLng(indexValue)

  On Error Resume Next
  Err.Clear
  Set obj = collectionObj.ElementAt(idx)
  If Err.Number <> 0 Or obj Is Nothing Then
    Err.Clear
    Set obj = collectionObj.Item(idx)
  End If
  Err.Clear
  On Error GoTo 0

  If Not obj Is Nothing Then Set CollectionElementAt = obj
End Function

Function FindConnectionById(SapApp, connectionId)
  Dim i, connection, connections
  Set FindConnectionById = Nothing
  If Trim(CStr(connectionId)) = "" Then Exit Function

  Set connections = SapApp.Connections
  For i = 0 To connections.Count - 1
    Set connection = CollectionElementAt(connections, CLng(i))
    If Not connection Is Nothing Then
      On Error Resume Next
      If CStr(connection.Id) = CStr(connectionId) Then
        Set FindConnectionById = connection
        On Error GoTo 0
        Exit Function
      End If
      On Error GoTo 0
    End If
  Next
End Function

Function FindSessionById(SapApp, sessionId, ByRef foundConnection)
  Dim i, j, connection, session, connections, sessions
  Set FindSessionById = Nothing
  Set foundConnection = Nothing

  If Trim(CStr(sessionId)) = "" Then Exit Function

  Set connections = SapApp.Connections
  For i = 0 To connections.Count - 1
    Set connection = CollectionElementAt(connections, CLng(i))
    If Not connection Is Nothing Then
      Set sessions = connection.Sessions
      For j = 0 To sessions.Count - 1
        Set session = CollectionElementAt(sessions, CLng(j))
        If Not session Is Nothing Then
          On Error Resume Next
          If CStr(session.Id) = CStr(sessionId) Then
            Set foundConnection = connection
            Set FindSessionById = session
            On Error GoTo 0
            Exit Function
          End If
          On Error GoTo 0
        End If
      Next
    End If
  Next
End Function

Function GetSapSession(sessionToken)
  Dim SapApp, connection, session, connections, sessions
  Set SapApp = GetSapApplication()

  If Trim(CStr(sessionToken)) <> "" Then
    Set session = FindSessionById(SapApp, sessionToken, connection)
    If session Is Nothing Then
      Fail "SAP_DEDICATED_SESSION_MISSING", "session", "A sessao dedicada do HAPCAPEX nao esta mais aberta: " & sessionToken
    End If
    Set GetSapSession = session
    Exit Function
  End If

  Set connections = SapApp.Connections
  If connections.Count = 0 Then
    Fail "SAP_NO_CONNECTION", "connection", "GetScriptingEngine retornou zero conexoes."
  End If

  Set connection = CollectionElementAt(connections, 0)
  If connection Is Nothing Then
    Fail "SAP_NO_CONNECTION", "connection", "A primeira conexao SAP nao pode ser obtida."
  End If

  Set sessions = connection.Sessions
  If sessions.Count = 0 Then
    Fail "SAP_NO_SESSION", "session", "A primeira conexao SAP nao possui sessao."
  End If

  Set session = CollectionElementAt(sessions, 0)
  If session Is Nothing Then
    Fail "SAP_NO_SESSION", "session", "A primeira sessao SAP nao pode ser obtida."
  End If

  Set GetSapSession = session
End Function

Sub CreateDedicatedSession()
  Dim SapApp, baseSession, baseConnection, baseConnectionId, beforeIds
  Dim sessions, i, candidate, candidateId, deadline, newSession
  Dim u, sys, cli, tx, title, newId, errMsg

  Set SapApp = GetSapApplication()
  Set baseSession = GetSapSession("")

  On Error Resume Next
  Err.Clear
  Set baseConnection = baseSession.Parent
  If Err.Number <> 0 Or baseConnection Is Nothing Then
    Err.Clear
    On Error GoTo 0
    Fail "SAP_CONNECTION_NOT_FOUND", "create_session", "Nao foi possivel identificar a conexao da sessao SAP atual."
  End If
  baseConnectionId = CStr(baseConnection.Id)
  On Error GoTo 0

  Set beforeIds = CreateObject("Scripting.Dictionary")
  Set sessions = baseConnection.Sessions
  For i = 0 To sessions.Count - 1
    Set candidate = CollectionElementAt(sessions, CLng(i))
    If Not candidate Is Nothing Then
      candidateId = ""
      On Error Resume Next
      candidateId = CStr(candidate.Id)
      On Error GoTo 0
      If Trim(candidateId) <> "" Then
        If Not beforeIds.Exists(candidateId) Then beforeIds.Add candidateId, True
      End If
    End If
  Next

  On Error Resume Next
  Err.Clear
  baseSession.CreateSession
  If Err.Number <> 0 Then
    errMsg = Err.Description
    Err.Clear
    On Error GoTo 0
    Fail "SAP_CREATE_SESSION_FAILED", "create_session", "Nao foi possivel criar uma nova sessao SAP: " & errMsg
  End If
  On Error GoTo 0

  Set newSession = Nothing
  deadline = DateAdd("s", 20, Now)
  Do
    WScript.Sleep 200
    Set SapApp = GetSapApplication()
    Set baseConnection = FindConnectionById(SapApp, baseConnectionId)

    If Not baseConnection Is Nothing Then
      Set sessions = baseConnection.Sessions
      For i = 0 To sessions.Count - 1
        Set candidate = CollectionElementAt(sessions, CLng(i))
        If Not candidate Is Nothing Then
          candidateId = ""
          On Error Resume Next
          candidateId = CStr(candidate.Id)
          On Error GoTo 0
          If Trim(candidateId) <> "" Then
            If Not beforeIds.Exists(candidateId) Then
              Set newSession = candidate
              Exit For
            End If
          End If
        End If
      Next
    End If

    If Not newSession Is Nothing Then Exit Do
  Loop While Now < deadline

  If newSession Is Nothing Then
    Fail "SAP_CREATE_SESSION_TIMEOUT", "create_session", "O SAP nao criou uma nova sessao identificavel dentro de 20 segundos. Pode haver limite de sessoes abertas."
  End If

  deadline = DateAdd("s", 10, Now)
  Do
    On Error Resume Next
    If Not newSession.Busy Then Exit Do
    On Error GoTo 0
    WScript.Sleep 150
  Loop While Now < deadline

  u = "" : sys = "" : cli = "" : tx = "" : title = "" : newId = ""
  On Error Resume Next
  newId = CStr(newSession.Id)
  u = newSession.Info.User
  sys = newSession.Info.SystemName
  cli = newSession.Info.Client
  tx = newSession.Info.Transaction
  title = newSession.findById("wnd[0]").Text
  On Error GoTo 0

  If Trim(newId) = "" Then
    Fail "SAP_CREATE_SESSION_FAILED", "create_session", "A nova sessao foi criada, mas seu identificador nao pode ser obtido."
  End If

  WScript.Echo "OK|DEDICATED|" & CleanField(newId) & "|" & CleanField(u) & "|" & CleanField(sys) & "|" & CleanField(cli) & "|" & CleanField(tx) & "|" & CleanField(title)
End Sub

Sub ProbeSession(sessionToken)
  Dim session, u, sys, cli, tx, title
  Set session = GetSapSession(sessionToken)

  u = "" : sys = "" : cli = "" : tx = "" : title = ""
  On Error Resume Next
  u = session.Info.User
  sys = session.Info.SystemName
  cli = session.Info.Client
  tx = session.Info.Transaction
  title = session.findById("wnd[0]").Text
  On Error GoTo 0

  WScript.Echo "OK|SESSION|" & CleanField(session.Id) & "|" & CleanField(u) & "|" & CleanField(sys) & "|" & CleanField(cli) & "|" & CleanField(tx) & "|" & CleanField(title)
End Sub

Sub CloseDedicatedSession(sessionToken)
  Dim SapApp, connection, session, sid, errMsg
  If Trim(sessionToken) = "" Then
    WScript.Echo "OK|CLOSED|"
    Exit Sub
  End If

  Set SapApp = GetSapApplication()
  Set session = FindSessionById(SapApp, sessionToken, connection)

  If session Is Nothing Then
    WScript.Echo "OK|CLOSED|" & CleanField(sessionToken)
    Exit Sub
  End If

  sid = CStr(session.Id)
  On Error Resume Next
  Err.Clear
  connection.CloseSession sid
  If Err.Number <> 0 Then
    errMsg = Err.Description
    Err.Clear
    On Error GoTo 0
    Fail "SAP_CLOSE_SESSION_FAILED", "close_session", "Nao foi possivel fechar a sessao dedicada: " & errMsg
  End If
  On Error GoTo 0

  WScript.Echo "OK|CLOSED|" & CleanField(sid)
End Sub

Function ElementExists(session, id)
  Dim obj
  On Error Resume Next
  Err.Clear
  Set obj = session.findById(id)
  ElementExists = (Err.Number = 0 And Not obj Is Nothing)
  Err.Clear
  On Error GoTo 0
End Function

Sub Probe()
  Dim session, u, sys, cli, tx, title
  Set session = GetSapSession("")

  u = "" : sys = "" : cli = "" : tx = "" : title = ""
  On Error Resume Next
  u = session.Info.User
  sys = session.Info.SystemName
  cli = session.Info.Client
  tx = session.Info.Transaction
  title = session.findById("wnd[0]").Text
  On Error GoTo 0

  ' This is intentionally enough: the working macro itself only needs session.
  WScript.Echo "OK|PROBE|" & CleanField(u) & "|" & CleanField(sys) & "|" & CleanField(cli) & "|" & CleanField(tx) & "|" & CleanField(title)
End Sub

Sub OpenBudcon(sessionToken)
  Dim session, treeId, opened, tx, statusText
  Set session = GetSapSession(sessionToken)
  opened = False

  On Error Resume Next
  session.findById("wnd[0]").maximize
  On Error GoTo 0

  ' First choice: EXACTLY the same navigation proven by AtualizarBases_v17.
  treeId = "wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell"
  If ElementExists(session, treeId) Then
    On Error Resume Next
    Err.Clear
    session.findById(treeId).selectedNode = "F00008"
    session.findById(treeId).doubleClickNode "F00008"
    If Err.Number = 0 Then opened = True
    Err.Clear
    On Error GoTo 0
    WScript.Sleep 700
  End If

  ' Fallback only if the user's proven F00008 navigation is unavailable.
  If Not opened Then
    On Error Resume Next
    Err.Clear
    session.StartTransaction "FMRP_RW_BUDCON"
    If Err.Number = 0 Then opened = True
    Err.Clear
    On Error GoTo 0
    WScript.Sleep 700
  End If

  statusText = ""
  On Error Resume Next
  statusText = session.findById("wnd[0]/sbar").Text
  tx = session.Info.Transaction
  On Error GoTo 0

  If InStr(1, UCase(statusText), "AUTORIZ", vbTextCompare) > 0 And _
     (InStr(1, UCase(statusText), "NAO", vbTextCompare) > 0 Or InStr(1, UCase(statusText), "N�O", vbTextCompare) > 0) Then
    Fail "SAP_TRANSACTION_UNAUTHORIZED", "open_transaction", statusText
  End If

  ' Strong confirmation: the input fields used by the macro are present.
  If ElementExists(session, "wnd[0]/usr/ctxt$4FFIKRS") And _
     ElementExists(session, "wnd[0]/usr/txt$4FFYEAR") And _
     ElementExists(session, "wnd[0]/usr/ctxt_4FFIPEX-LOW") Then
    WScript.Echo "OK|BUDCON|" & CleanField(tx) & "|" & CleanField(statusText)
    Exit Sub
  End If

  If opened Then
    WScript.Echo "OK|BUDCON|" & CleanField(tx) & "|" & CleanField(statusText)
  Else
    Fail "SAP_TRANSACTION_NOT_FOUND", "open_transaction", "Nao foi possivel abrir F00008 nem FMRP_RW_BUDCON."
  End If
End Sub

Function WaitForLayoutGrid(session, timeoutSeconds)
  Dim deadline, gridId, grid
  gridId = "wnd[1]/usr/subSUB_CONFIGURATION:SAPLSALV_CUL_LAYOUT_CHOOSE:0500/cntlD500_CONTAINER/shellcont/shell"
  deadline = DateAdd("s", timeoutSeconds, Now)

  Do
    On Error Resume Next
    Err.Clear
    Set grid = session.findById(gridId)
    If Err.Number = 0 And Not grid Is Nothing Then
      If grid.RowCount > 0 Then
        On Error GoTo 0
        Set WaitForLayoutGrid = grid
        Exit Function
      End If
    End If
    Err.Clear
    On Error GoTo 0
    WScript.Sleep 200
  Loop While Now < deadline

  Set WaitForLayoutGrid = Nothing
End Function

Function OpenLayoutChooser(session)
  Dim grid, openedByButton, eKey
  Set grid = Nothing
  openedByButton = False

  On Error Resume Next
  Err.Clear
  session.findById("wnd[0]/tbar[1]/btn[33]").press
  If Err.Number = 0 Then openedByButton = True
  Err.Clear
  On Error GoTo 0

  If openedByButton Then
    Set grid = WaitForLayoutGrid(session, 5)
    If Not grid Is Nothing Then
      Set OpenLayoutChooser = grid
      Exit Function
    End If
  End If

  On Error Resume Next
  Err.Clear
  session.findById("wnd[0]").sendVKey 33
  If Err.Number <> 0 Then
    eKey = Err.Description
    Err.Clear
    On Error GoTo 0
    Fail "SAP_LAYOUT_DIALOG_FAILED", "open_layout_dialog", "Nao foi possivel abrir a selecao de layout pelo botao nem por Ctrl+F9: " & eKey
  End If
  On Error GoTo 0

  Set grid = WaitForLayoutGrid(session, 8)
  If grid Is Nothing Then
    Fail "SAP_LAYOUT_DIALOG_FAILED", "open_layout_dialog", "A tela de selecao de layout nao apareceu apos o botao e Ctrl+F9."
  End If

  Set OpenLayoutChooser = grid
End Function

Function ColumnExists(grid, columnId)
  Dim cols, c, i
  ColumnExists = False
  On Error Resume Next
  Set cols = grid.ColumnOrder
  If Err.Number <> 0 Or cols Is Nothing Then
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If

  For i = 0 To cols.Count - 1
    c = CStr(cols.Item(i))
    If UCase(Trim(c)) = UCase(Trim(columnId)) Then
      ColumnExists = True
      Exit For
    End If
  Next
  Err.Clear
  On Error GoTo 0
End Function

Function FindLayoutRow(grid, wantedLayout, ByRef foundColumn, ByRef diag)
  Dim rowCount, visibleCount, pageStart, pageEnd, r, ci
  Dim cols, colId, value, wanted, firstChoice
  Dim maxStart

  FindLayoutRow = -1
  foundColumn = ""
  diag = ""
  wanted = UCase(Trim(wantedLayout))
  firstChoice = ""

  On Error Resume Next
  rowCount = CLng(grid.RowCount)
  visibleCount = CLng(grid.VisibleRowCount)
  Set cols = grid.ColumnOrder
  If Err.Number <> 0 Or cols Is Nothing Then
    diag = "Nao foi possivel ler ColumnOrder da grade: " & Err.Description
    Err.Clear
    On Error GoTo 0
    Exit Function
  End If
  Err.Clear
  On Error GoTo 0

  If visibleCount < 1 Then visibleCount = 1
  diag = "rows=" & CStr(rowCount) & "; visible=" & CStr(visibleCount) & "; cols="
  For ci = 0 To cols.Count - 1
    colId = CStr(cols.Item(ci))
    If ci > 0 Then diag = diag & ","
    diag = diag & colId
    If UCase(colId) = "LAYOUT" Then firstChoice = colId
  Next

  pageStart = 0
  Do While pageStart < rowCount
    maxStart = rowCount - visibleCount
    If maxStart < 0 Then maxStart = 0
    If pageStart > maxStart Then
      grid.FirstVisibleRow = maxStart
      pageEnd = rowCount - 1
    Else
      grid.FirstVisibleRow = pageStart
      pageEnd = pageStart + visibleCount - 1
      If pageEnd > rowCount - 1 Then pageEnd = rowCount - 1
    End If
    WScript.Sleep 120

    For r = pageStart To pageEnd
      If firstChoice <> "" Then
        value = ""
        On Error Resume Next
        Err.Clear
        value = CStr(grid.GetCellValue(r, firstChoice))
        Err.Clear
        On Error GoTo 0
        If UCase(Trim(value)) = wanted Then
          foundColumn = firstChoice
          FindLayoutRow = r
          Exit Function
        End If
      End If

      For ci = 0 To cols.Count - 1
        colId = CStr(cols.Item(ci))
        If UCase(colId) <> UCase(firstChoice) Then
          value = ""
          On Error Resume Next
          Err.Clear
          value = CStr(grid.GetCellValue(r, colId))
          Err.Clear
          On Error GoTo 0
          If UCase(Trim(value)) = wanted Then
            foundColumn = colId
            FindLayoutRow = r
            Exit Function
          End If
        End If
      Next
    Next

    pageStart = pageStart + visibleCount
  Loop
End Function

Sub SelectLayoutByCode(session, layoutCode)
  Dim grid, rowIndex, foundColumn, diag, selectColumn, targetFirst, eSel
  Set grid = OpenLayoutChooser(session)

  rowIndex = FindLayoutRow(grid, layoutCode, foundColumn, diag)
  If rowIndex < 0 Then
    Fail "SAP_LAYOUT_NOT_FOUND", "select_layout", "Layout " & layoutCode & " nao encontrado apos varrer toda a grade. Diagnostico: " & diag
  End If

  targetFirst = rowIndex - 3
  If targetFirst < 0 Then targetFirst = 0
  On Error Resume Next
  grid.FirstVisibleRow = targetFirst
  Err.Clear
  On Error GoTo 0
  WScript.Sleep 150

  selectColumn = foundColumn
  If ColumnExists(grid, "TEXT") Then selectColumn = "TEXT"

  On Error Resume Next
  Err.Clear
  grid.setCurrentCell rowIndex, selectColumn
  grid.selectedRows = CStr(rowIndex)
  grid.clickCurrentCell
  If Err.Number <> 0 Then
    eSel = Err.Description
    Err.Clear
    On Error GoTo 0
    Fail "SAP_LAYOUT_SELECT_FAILED", "select_layout", "O layout foi localizado na linha " & CStr(rowIndex) & ", mas nao foi possivel seleciona-lo: " & eSel
  End If
  On Error GoTo 0

  WScript.Sleep 900
End Sub

Sub ExportConsumo(yearValue, exportDir, sessionToken)
  Dim session
  Dim baseName, expectedFile, fso, deadline

  If exportDir = "" Then Fail "EXPORT_PATH_MISSING", "export", "Pasta de exportacao nao informada."
  Set session = GetSapSession(sessionToken)

  ' If user is still on Easy Access, open the same F00008 node as the macro.
  If Not ElementExists(session, "wnd[0]/usr/ctxt$4FFIKRS") Then
    Dim treeId
    treeId = "wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell"
    If ElementExists(session, treeId) Then
      On Error Resume Next
      session.findById(treeId).selectedNode = "F00008"
      session.findById(treeId).doubleClickNode "F00008"
      If Err.Number <> 0 Then
        Dim e1
        e1 = Err.Description
        Err.Clear
        On Error GoTo 0
        Fail "SAP_OPEN_BUDCON_FAILED", "open_transaction", e1
      End If
      On Error GoTo 0
      WScript.Sleep 700
    Else
      On Error Resume Next
      session.StartTransaction "FMRP_RW_BUDCON"
      If Err.Number <> 0 Then
        Dim e2
        e2 = Err.Description
        Err.Clear
        On Error GoTo 0
        Fail "SAP_OPEN_BUDCON_FAILED", "open_transaction", e2
      End If
      On Error GoTo 0
      WScript.Sleep 700
    End If
  End If

  On Error Resume Next
  session.findById("wnd[0]").maximize

  Err.Clear
  session.findById("wnd[0]/usr/ctxt$4FFIKRS").Text = "HAPV"
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "fill_fund", Err.Description
  Err.Clear
  session.findById("wnd[0]/usr/txt$4FFYEAR").Text = yearValue
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "fill_year", Err.Description
  Err.Clear
  session.findById("wnd[0]/usr/ctxt_4FFIPEX-LOW").Text = "sho_obras"
  session.findById("wnd[0]/usr/ctxt_4FFIPEX-LOW").SetFocus
  session.findById("wnd[0]/usr/ctxt_4FFIPEX-LOW").caretPosition = 9
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "fill_program", Err.Description
  Err.Clear
  session.findById("wnd[0]").sendVKey 8
  If Err.Number <> 0 Then Fail "SAP_EXECUTE_FAILED", "execute_budcon", Err.Description
  On Error GoTo 0
  WScript.Sleep 900

  ' EXACT sequence from the working macro.
  On Error Resume Next
  Err.Clear
  session.findById("wnd[0]/shellcont/shell/shellcont[1]/shell").topNode = "000001"
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "open_report_tree", Err.Description
  session.findById("wnd[0]/usr/lbl[65,12]").SetFocus
  session.findById("wnd[0]/usr/lbl[65,12]").caretPosition = 7
  session.findById("wnd[0]").sendVKey 2
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "select_report_line", Err.Description
  On Error GoTo 0
  WScript.Sleep 350

  On Error Resume Next
  Err.Clear
  session.findById("wnd[1]/usr/lbl[1,1]").caretPosition = 20
  session.findById("wnd[1]").sendVKey 2
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "confirm_report_line", Err.Description
  On Error GoTo 0
  WScript.Sleep 350

  ' Open the chooser explicitly and find /IRLANDO by content.
  ' No fixed-row fallback is allowed.
  SelectLayoutByCode session, "/IRLANDO"

  On Error Resume Next
  Err.Clear
  session.findById("wnd[0]/tbar[1]/btn[46]").press
  session.findById("wnd[0]/tbar[1]/btn[43]").press
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "open_export", Err.Description
  On Error GoTo 0
  WScript.Sleep 450

  baseName = "base consumo " & Year(Now) & Right("0" & Month(Now),2) & Right("0" & Day(Now),2) & "_" & _
             Right("0" & Hour(Now),2) & Right("0" & Minute(Now),2) & Right("0" & Second(Now),2)
  expectedFile = exportDir & "\" & baseName & ".xlsx"

  Set fso = CreateObject("Scripting.FileSystemObject")
  If fso.FileExists(expectedFile) Then
    On Error Resume Next
    fso.DeleteFile expectedFile, True
    On Error GoTo 0
  End If

  On Error Resume Next
  Err.Clear
  session.findById("wnd[1]/usr/ssubSUB_CONFIGURATION:SAPLSALV_GUI_CUL_EXPORT_AS:0512/txtGS_EXPORT-FILE_NAME").Text = baseName
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "set_export_name", Err.Description

  Err.Clear
  session.findById("wnd[1]/usr/ssubSUB_CONFIGURATION:SAPLSALV_GUI_CUL_EXPORT_AS:0512/cmbGS_EXPORT-DESTINATION").SetFocus
  session.findById("wnd[1]/tbar[0]/btn[20]").press
  If Err.Number <> 0 Then Fail "SAP_SCREEN_CHANGED", "open_export_path", Err.Description
  On Error GoTo 0
  WScript.Sleep 300

  On Error Resume Next
  Err.Clear
  session.findById("wnd[1]/usr/ctxtDY_PATH").Text = exportDir
  session.findById("wnd[1]/usr/ctxtDY_PATH").SetFocus
  session.findById("wnd[1]/usr/ctxtDY_PATH").caretPosition = 0
  session.findById("wnd[1]/tbar[0]/btn[11]").press
  If Err.Number <> 0 Then Fail "SAP_EXPORT_FAILED", "confirm_export", Err.Description
  On Error GoTo 0

  deadline = DateAdd("s", 180, Now)
  Do
    If fso.FileExists(expectedFile) Then
      On Error Resume Next
      Dim ff
      Set ff = fso.GetFile(expectedFile)
      If Err.Number = 0 Then
        If ff.Size > 0 Then
          On Error GoTo 0
          WScript.Echo "OK|EXPORT|" & CleanField(expectedFile) & "|" & CStr(ff.Size)
          Exit Sub
        End If
      End If
      Err.Clear
      On Error GoTo 0
    End If
    WScript.Sleep 500
  Loop While Now < deadline

  Fail "SAP_EXPORT_TIMEOUT", "wait_export", "O arquivo Excel nao foi gerado dentro de 180 segundos."
End Sub

Select Case action
  Case "probe"
    Probe
  Case "create-session"
    CreateDedicatedSession
  Case "probe-session"
    ProbeSession param1
  Case "close-session"
    CloseDedicatedSession param1
  Case "open-budcon"
    OpenBudcon param1
  Case "export-consumo"
    If Trim(param1) = "" Then param1 = CStr(Year(Date))
    ExportConsumo param1, param2, param3
  Case Else
    Fail "UNKNOWN_ACTION", "init", "Acao desconhecida: " & action
End Select
