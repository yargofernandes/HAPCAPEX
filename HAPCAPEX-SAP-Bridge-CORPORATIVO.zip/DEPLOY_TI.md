﻿# DEPLOY T.I.
Versão: 1.1.5-alpha
Escopo: CurrentUser
Porta: 127.0.0.1:17891

IMPORTANTE: implantar em contexto do usuário logado, pois o Bridge precisa acessar a sessão SAP GUI interativa.


SEGURANÇA 1.1.5
- Endpoints SAP exigem pareamento temporário com sessão autenticada do HAPCAPEX.
- Token local existe apenas na memória e expira.
- Senha SAP não é lida nem armazenada.
