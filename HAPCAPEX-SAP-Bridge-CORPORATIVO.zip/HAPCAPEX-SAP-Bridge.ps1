﻿param(
  [string]$Protocol = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$BridgeVersion = '1.1.5-alpha'

$MacroHelperPath = Join-Path $PSScriptRoot 'HAPCAPEX-SAP-MacroBridge.vbs'

function Get-CscriptCandidates {
  $list = New-Object System.Collections.Generic.List[string]
  $win = $env:WINDIR
  foreach ($p in @(
    (Join-Path $win 'SysWOW64\cscript.exe'),
    (Join-Path $win 'System32\cscript.exe'),
    (Join-Path $win 'Sysnative\cscript.exe')
  )) {
    if ($p -and (Test-Path -LiteralPath $p) -and -not $list.Contains($p)) { $list.Add($p) }
  }
  return @($list)
}

function Invoke-MacroSapHelper {
  param(
    [Parameter(Mandatory=$true)][string]$Action,
    [string[]]$Arguments = @(),
    [int]$TimeoutSeconds = 30
  )

  if (-not (Test-Path -LiteralPath $MacroHelperPath)) {
    return [pscustomobject]@{ ok=$false; code='MACRO_HELPER_MISSING'; step='helper'; message='HAPCAPEX-SAP-MacroBridge.vbs nao foi encontrado.'; raw=''; host='' }
  }

  $last = $null
  foreach ($cscript in (Get-CscriptCandidates)) {
    $stdout = Join-Path $env:TEMP ('hapcapex_vbs_' + [guid]::NewGuid().ToString('N') + '.out')
    $stderr = Join-Path $env:TEMP ('hapcapex_vbs_' + [guid]::NewGuid().ToString('N') + '.err')
    try {
      $argList = @('//NoLogo', $MacroHelperPath, $Action) + @($Arguments)
      Write-BridgeLog ("Macro helper: {0} {1}" -f $cscript,($argList -join ' '))
      $proc = Start-Process -FilePath $cscript -ArgumentList $argList -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
      if (-not $proc.WaitForExit($TimeoutSeconds * 1000)) {
        try { $proc.Kill() } catch {}
        $last = [pscustomobject]@{ ok=$false; code='MACRO_HELPER_TIMEOUT'; step=$Action; message=("Helper excedeu {0}s." -f $TimeoutSeconds); raw=''; host=$cscript }
        continue
      }
      $outText = ''
      $errText = ''
      try { $outText = (Get-Content -LiteralPath $stdout -Raw -ErrorAction SilentlyContinue).Trim() } catch {}
      try { $errText = (Get-Content -LiteralPath $stderr -Raw -ErrorAction SilentlyContinue).Trim() } catch {}
      Write-BridgeLog ("Macro helper [{0}] exit={1} out={2} err={3}" -f $cscript,$proc.ExitCode,$outText,$errText)

      $line = ($outText -split "`r?`n" | Where-Object { $_ -match '^(OK|ERR)\|' } | Select-Object -Last 1)
      if (-not $line) {
        $last = [pscustomobject]@{ ok=$false; code='MACRO_HELPER_NO_OUTPUT'; step=$Action; message=($errText + ' ' + $outText).Trim(); raw=$outText; host=$cscript }
        continue
      }
      $parts = $line.Split('|')
      if ($parts[0] -eq 'OK') {
        return [pscustomobject]@{ ok=$true; kind=if($parts.Count -gt 1){$parts[1]}else{''}; parts=$parts; raw=$line; host=$cscript }
      }
      $last = [pscustomobject]@{
        ok=$false
        code=if($parts.Count -gt 1){$parts[1]}else{'MACRO_HELPER_ERROR'}
        step=if($parts.Count -gt 2){$parts[2]}else{$Action}
        message=if($parts.Count -gt 3){$parts[3]}else{$line}
        raw=$line
        host=$cscript
      }
      # GetObject failure can be bitness-specific, so try the next cscript host.
      if ($last.code -notin @('SAP_GETOBJECT_FAILED','SAP_SCRIPTING_ENGINE_FAILED','SAP_NO_CONNECTION','SAP_NO_SESSION')) {
        return $last
      }
    } finally {
      Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
    }
  }
  return $last
}

function Confirm-SapLoginViaMacro {
  param([bool]$HardFail = $true)

  $r = Invoke-MacroSapHelper -Action 'probe' -TimeoutSeconds 12
  if ($r -and $r.ok) {
    $State.sessionConnected = $true
    if ($r.parts.Count -gt 2) { $State.sapUser = [string]$r.parts[2] }
    if ($r.parts.Count -gt 3) { $State.sapSystem = [string]$r.parts[3] }
    if ($r.parts.Count -gt 4) { $State.sapClient = [string]$r.parts[4] }
    if ($r.parts.Count -gt 5) { $State.transaction = [string]$r.parts[5] }
    if ($r.parts.Count -gt 6) { $State.sapWindowTitle = [string]$r.parts[6] }
    Set-BridgeState 'session_ready' 'session_ready' 'Login SAP identificado pelo mesmo GetObject("SAPGUI") usado na macro.'
    Write-BridgeLog ("Macro probe OK host={0} raw={1}" -f $r.host,$r.raw)
    return $true
  }

  $State.sessionConnected = $false
  $detail = if($r){$r.message}else{'Helper SAP nao retornou diagnostico.'}
  $code = if($r){$r.code}else{'SAP_MACRO_PROBE_FAILED'}

  if ($HardFail) {
    Set-BridgeError $code 'A macro não conseguiu obter a sessão SAP' $detail 'Deixe o SAP Easy Access aberto e autenticado. O HAPCAPEX usa exatamente o mesmo GetObject("SAPGUI") validado no diagnóstico.' 'login'
  } else {
    $State.state = 'awaiting_login'
    $State.currentStep = 'login'
    $State.message = 'Aguardando login no SAP. Assim que o SAP Easy Access estiver autenticado, o HAPCAPEX continuará automaticamente.'
    $State.lastError = $null
    Touch-State
    Write-BridgeLog ("Macro probe ainda sem sessao. CODE={0} MSG={1}" -f $code,$detail)
  }
  return $false
}

function Test-DedicatedSapSessionViaMacro {
  if (-not $State.dedicatedSessionId) { return $false }
  $r = Invoke-MacroSapHelper -Action 'probe-session' -Arguments @([string]$State.dedicatedSessionId) -TimeoutSeconds 10
  if ($r -and $r.ok) { return $true }
  Write-BridgeLog ("Sessao dedicada anterior nao esta mais disponivel: {0}" -f $State.dedicatedSessionId) 'WARN'
  $State.dedicatedSessionId = $null
  $State.dedicatedSessionCreatedAt = $null
  Touch-State
  return $false
}

function Ensure-DedicatedSapSessionViaMacro {
  if (Test-DedicatedSapSessionViaMacro) { return $true }

  Set-BridgeState 'working' 'create_session' 'Criando uma sessao SAP exclusiva para o HAPCAPEX...'
  $r = Invoke-MacroSapHelper -Action 'create-session' -TimeoutSeconds 25
  if ($r -and $r.ok -and $r.parts.Count -gt 2) {
    $sid = [string]$r.parts[2]
    if ([string]::IsNullOrWhiteSpace($sid)) {
      Set-BridgeError 'SAP_CREATE_SESSION_FAILED' 'Nova sessão SAP sem identificador' 'O SAP abriu uma nova sessão, mas o HAPCAPEX não recebeu seu ID.' 'Feche a janela nova e tente novamente.' 'create_session'
      return $false
    }
    $State.dedicatedSessionId = $sid
    $State.dedicatedSessionCreatedAt = (Get-Date).ToString('o')
    $State.sessionConnected = $true
    if ($r.parts.Count -gt 3) { $State.sapUser = [string]$r.parts[3] }
    if ($r.parts.Count -gt 4) { $State.sapSystem = [string]$r.parts[4] }
    if ($r.parts.Count -gt 5) { $State.sapClient = [string]$r.parts[5] }
    if ($r.parts.Count -gt 6) { $State.transaction = [string]$r.parts[6] }
    if ($r.parts.Count -gt 7) { $State.sapWindowTitle = [string]$r.parts[7] }
    Set-BridgeState 'dedicated_session_ready' 'dedicated_session_ready' 'Sessão exclusiva do HAPCAPEX criada. Suas outras janelas SAP não serão alteradas.'
    Write-BridgeLog ("Sessao SAP dedicada criada: {0}" -f $sid)
    return $true
  }

  $detail = if($r){$r.message}else{'Falha sem diagnóstico.'}
  $code = if($r){$r.code}else{'SAP_CREATE_SESSION_FAILED'}
  Set-BridgeError $code 'Não foi possível abrir uma nova sessão SAP' $detail 'Feche uma janela SAP que não esteja usando e tente novamente. O SAP pode ter atingido o limite de sessões simultâneas.' 'create_session'
  return $false
}

function Close-DedicatedSapSessionViaMacro {
  param([bool]$Silent = $true)
  $sid = [string]$State.dedicatedSessionId
  if ([string]::IsNullOrWhiteSpace($sid)) { return $true }

  $r = Invoke-MacroSapHelper -Action 'close-session' -Arguments @($sid) -TimeoutSeconds 15
  if ($r -and $r.ok) {
    Write-BridgeLog ("Sessao SAP dedicada encerrada: {0}" -f $sid)
    $State.dedicatedSessionId = $null
    $State.dedicatedSessionCreatedAt = $null
    Touch-State
    return $true
  }

  $detail = if($r){$r.message}else{'Falha sem diagnóstico.'}
  Write-BridgeLog ("Nao foi possivel fechar sessao dedicada {0}: {1}" -f $sid,$detail) 'WARN'
  if (-not $Silent) {
    Set-BridgeError 'SAP_CLOSE_SESSION_FAILED' 'Não foi possível fechar a sessão exclusiva do HAPCAPEX' $detail 'Você pode fechar manualmente apenas a janela utilizada pelo HAPCAPEX.' 'close_session'
  }
  return $false
}

function Reset-SapCycle {
  param(
    [bool]$CloseDedicated = $true,
    [bool]$DeleteExport = $false,
    [string]$Message = 'SAP Bridge pronto para uma nova atualização.'
  )

  if ($CloseDedicated) { [void](Close-DedicatedSapSessionViaMacro $true) }

  if ($DeleteExport -and $State.exportFile -and (Test-Path -LiteralPath $State.exportFile)) {
    try {
      Remove-Item -LiteralPath $State.exportFile -Force -ErrorAction Stop
      Write-BridgeLog ("Export local removido ao concluir ciclo: {0}" -f $State.exportFile)
    } catch {
      Write-BridgeLog ("Nao foi possivel remover export local: {0}" -f $_.Exception.Message) 'WARN'
    }
  }

  $State.state='idle'
  $State.currentStep='bridge_ready'
  $State.message=$Message
  $State.lastError=$null
  $State.exportFile=$null
  $State.exportFileName=$null
  $State.exportBytes=0
  $State.sessionConnected=$false
  $State.transaction=$null
  $State.sapUser=$null
  $State.sapSystem=$null
  $State.sapClient=$null
  $State.sapWindowTitle=$null
  $State.dedicatedSessionId=$null
  $State.dedicatedSessionCreatedAt=$null
  Touch-State
}

function Open-BudconViaMacro {
  if (-not (Ensure-DedicatedSapSessionViaMacro)) { return $false }

  Set-BridgeState 'working' 'open_transaction' 'Abrindo FMRP_RW_BUDCON na sessão exclusiva do HAPCAPEX...'
  $r = Invoke-MacroSapHelper -Action 'open-budcon' -Arguments @([string]$State.dedicatedSessionId) -TimeoutSeconds 25
  if ($r -and $r.ok) {
    $State.sessionConnected = $true
    $State.transaction = if($r.parts.Count -gt 2){[string]$r.parts[2]}else{'FMRP_RW_BUDCON'}
    Set-BridgeState 'transaction_ready' 'transaction_ready' 'FMRP_RW_BUDCON aberta na sessão exclusiva do HAPCAPEX.'
    return $true
  }

  $detail = if($r){$r.message}else{'Falha sem diagnostico.'}
  $code = if($r){$r.code}else{'SAP_TRANSACTION_NOT_FOUND'}
  if($code -eq 'SAP_TRANSACTION_UNAUTHORIZED'){
    Set-BridgeError $code 'Usuário sem acesso à transação' $detail 'Abra um chamado junto à T.I. solicitando acesso à FMRP_RW_BUDCON.' 'open_transaction'
  } elseif($code -eq 'SAP_DEDICATED_SESSION_MISSING') {
    $State.dedicatedSessionId=$null
    $State.dedicatedSessionCreatedAt=$null
    Set-BridgeError $code 'A sessão exclusiva do HAPCAPEX foi fechada' $detail 'Clique em tentar novamente; o HAPCAPEX criará uma nova sessão.' 'create_session'
  } else {
    Set-BridgeError $code 'Não foi possível abrir FMRP_RW_BUDCON' $detail 'O HAPCAPEX usa primeiro o nó F00008 exatamente como sua macro. Se persistir, envie o bridge.log.' 'open_transaction'
  }
  return $false
}

function Export-BaseConsumoViaMacro {
  param([int]$Year)
  if($Year -lt 2000 -or $Year -gt 2100){$Year=(Get-Date).Year}
  if (-not (Test-DedicatedSapSessionViaMacro)) {
    Set-BridgeError 'SAP_DEDICATED_SESSION_MISSING' 'Sessão exclusiva do HAPCAPEX não está disponível' 'A janela SAP criada para esta atualização foi fechada ou perdida.' 'Clique em tentar novamente para criar uma nova sessão.' 'create_session'
    return $false
  }
  $State.state='exporting'; $State.currentStep='fill_budcon'; $State.message='Executando a Base Consumo pelo fluxo validado da macro...'; $State.lastError=$null; Touch-State

  $r = Invoke-MacroSapHelper -Action 'export-consumo' -Arguments @([string]$Year,[string]$ExportDir,[string]$State.dedicatedSessionId) -TimeoutSeconds 210
  if($r -and $r.ok -and $r.parts.Count -gt 2){
    $file=[string]$r.parts[2]
    if(-not (Test-Path -LiteralPath $file)){
      Set-BridgeError 'SAP_EXPORT_FILE_MISSING' 'O SAP informou a exportação, mas o arquivo não foi localizado' $file 'Tente novamente e verifique permissões da pasta local do HAPCAPEX.' 'wait_export'
      return $false
    }
    $fi=Get-Item -LiteralPath $file
    $State.exportFile=$fi.FullName; $State.exportFileName=$fi.Name; $State.exportBytes=[int64]$fi.Length
    Set-BridgeState 'export_ready' 'export_ready' ("Base Consumo exportada pela macro: {0}" -f $fi.Name)
    return $true
  }

  $detail=if($r){$r.message}else{'Falha sem diagnostico.'}
  $code=if($r){$r.code}else{'SAP_EXPORT_FAILED'}
  switch($code){
    'SAP_LAYOUT_NOT_FOUND' { Set-BridgeError $code 'Layout /IRLANDO não encontrado' $detail 'Verifique se o layout /IRLANDO está disponível para seu usuário.' 'select_layout' }
    'SAP_TRANSACTION_UNAUTHORIZED' { Set-BridgeError $code 'Usuário sem acesso à transação' $detail 'Abra um chamado junto à T.I. solicitando acesso.' 'execute_budcon' }
    'SAP_SCREEN_CHANGED' { Set-BridgeError $code 'Tela SAP diferente da macro validada' $detail 'Envie o bridge.log; ajustaremos o elemento exato sem continuar às cegas.' 'sap_screen' }
    default { Set-BridgeError $code 'Falha ao extrair Base Consumo pelo fluxo da macro' $detail 'Tente novamente. Se persistir, envie o bridge.log.' 'export_consumo' }
  }
  return $false
}
$Port = 17891
$DistributionVersion = '1.0.7'
$SupabaseUrl = 'https://kuvwfyuhrnfsubkapeek.supabase.co'
$SupabaseAnonKey = 'sb_publishable_-MtsnK_nyG5ZryuLDynTdg_R8hT1s66'
$BridgePairTtlMinutes = 20
$BridgeSessions = @{}
$BaseDir = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
$ExportDir = Join-Path $BaseDir 'exports'
$ConfigPath = Join-Path $BaseDir 'config.json'
$LogPath = Join-Path $BaseDir 'bridge.log'
$PidPath = Join-Path $BaseDir 'bridge.pid'
$DefaultTransaction = 'FMRP_RW_BUDCON'
$ExpectedLayout = '/IRLANDO'
$DefaultOrigins = @(
  'https://yargofernandes.github.io',
  'http://localhost',
  'http://127.0.0.1'
)

New-Item -ItemType Directory -Path $BaseDir -Force | Out-Null
New-Item -ItemType Directory -Path $ExportDir -Force | Out-Null

function Write-BridgeLog {
  param([string]$Message, [string]$Level = 'INFO')
  try {
    $line = ('{0:yyyy-MM-dd HH:mm:ss.fff} [{1}] {2}' -f (Get-Date), $Level, $Message)
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
  } catch {}
}

function New-DefaultConfig {
  [pscustomobject]@{
    sapExecutablePath = $null
    preferredTransactionCode = $DefaultTransaction
    allowedOrigins = $DefaultOrigins
    lastSuccessfulLayout = $ExpectedLayout
    securityMode = 'supabase-paired-session-v1'
    lastUpdatedAt = $null
  }
}

function Save-BridgeConfig {
  param($Config)
  $Config.lastUpdatedAt = (Get-Date).ToString('o')
  $Config | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}

function Load-BridgeConfig {
  if (-not (Test-Path -LiteralPath $ConfigPath)) {
    $cfg = New-DefaultConfig
    Save-BridgeConfig $cfg
    return $cfg
  }
  try {
    $cfg = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $cfg.preferredTransactionCode) { $cfg.preferredTransactionCode = $DefaultTransaction }
    if (-not $cfg.allowedOrigins) { $cfg.allowedOrigins = $DefaultOrigins }
    if (-not $cfg.lastSuccessfulLayout) { $cfg.lastSuccessfulLayout = $ExpectedLayout }
    return $cfg
  } catch {
    Write-BridgeLog ('Falha ao ler config.json. Recriando: ' + $_.Exception.Message) 'WARN'
    $cfg = New-DefaultConfig
    Save-BridgeConfig $cfg
    return $cfg
  }
}

$Config = Load-BridgeConfig

$State = @{
  version = $BridgeVersion
  processId = $PID
  startedAt = (Get-Date).ToString('o')
  state = 'idle'
  currentStep = 'bridge_ready'
  message = 'SAP Bridge pronto.'
  sapFound = $false
  sapPath = $null
  sapRunning = $false
  sessionConnected = $false
  transaction = $null
  dedicatedSessionId = $null
  dedicatedSessionCreatedAt = $null
  machineName = $env:COMPUTERNAME
  windowsUser = $env:USERNAME
  sapUser = $null
  sapSystem = $null
  sapClient = $null
  sapWindowTitle = $null
  exportFile = $null
  exportFileName = $null
  exportBytes = 0
  lastError = $null
  updatedAt = (Get-Date).ToString('o')
}

function Touch-State {
  $State.updatedAt = (Get-Date).ToString('o')
}

function Set-BridgeState {
  param([string]$Name, [string]$Step, [string]$Message)
  $State.state = $Name
  $State.currentStep = $Step
  $State.message = $Message
  $State.lastError = $null
  Touch-State
  Write-BridgeLog ("STATE=$Name STEP=$Step MSG=$Message")
}

function Set-BridgeError {
  param(
    [string]$Code,
    [string]$Title,
    [string]$Message,
    [string]$Solution,
    [string]$Step = 'unknown'
  )
  $State.state = 'error'
  $State.currentStep = $Step
  $State.message = $Message
  $State.lastError = @{
    code = $Code
    title = $Title
    message = $Message
    solution = $Solution
    step = $Step
  }
  Touch-State
  Write-BridgeLog ("ERROR=$Code STEP=$Step MSG=$Message SOL=$Solution") 'ERROR'
}

function Get-JsonBody {
  param([string]$Body)
  if ([string]::IsNullOrWhiteSpace($Body)) { return $null }
  try { return $Body | ConvertFrom-Json } catch { return $null }
}

function Normalize-PathCandidate {
  param([string]$Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { return $null }
  try {
    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim('"',' '))
    if (Test-Path -LiteralPath $expanded -PathType Leaf) {
      $leaf = [IO.Path]::GetFileName($expanded)
      if ($leaf -match '^(saplogon|saplgpad)\.exe$') { return (Resolve-Path -LiteralPath $expanded).Path }
    }
    if (Test-Path -LiteralPath $expanded -PathType Container) {
      foreach ($name in @('saplogon.exe','saplgpad.exe')) {
        $direct = Join-Path $expanded $name
        if (Test-Path -LiteralPath $direct -PathType Leaf) { return (Resolve-Path -LiteralPath $direct).Path }
      }
      $found = Get-ChildItem -LiteralPath $expanded -Filter 'saplogon.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
      if (-not $found) { $found = Get-ChildItem -LiteralPath $expanded -Filter 'saplgpad.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 }
      if ($found) { return $found.FullName }
    }
  } catch {}
  return $null
}

function Resolve-ShortcutTarget {
  param([string]$ShortcutPath)
  try {
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($ShortcutPath)
    return (Normalize-PathCandidate $sc.TargetPath)
  } catch { return $null }
}

function Find-SapExecutable {
  param([string]$ManualPath = '')

  if ($ManualPath) {
    $manual = Normalize-PathCandidate $ManualPath
    if ($manual) {
      $Config.sapExecutablePath = $manual
      Save-BridgeConfig $Config
      return $manual
    }
  }

  if ($Config.sapExecutablePath) {
    $saved = Normalize-PathCandidate ([string]$Config.sapExecutablePath)
    if ($saved) { return $saved }
  }

  $appPathKeys = @(
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\saplogon.exe',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\saplogon.exe',
    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\saplogon.exe',
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\saplgpad.exe',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\saplgpad.exe',
    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\saplgpad.exe'
  )
  foreach ($key in $appPathKeys) {
    try {
      if (Test-Path $key) {
        $item = Get-Item $key
        $candidate = Normalize-PathCandidate ([string]$item.GetValue(''))
        if ($candidate) { $Config.sapExecutablePath = $candidate; Save-BridgeConfig $Config; return $candidate }
      }
    } catch {}
  }

  $common = @()
  if ($env:ProgramFiles) { $common += (Join-Path $env:ProgramFiles 'SAP\FrontEnd\SAPgui\saplogon.exe') }
  $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
  if ($pf86) { $common += (Join-Path $pf86 'SAP\FrontEnd\SAPgui\saplogon.exe') }
  if ($env:ProgramFiles) { $common += (Join-Path $env:ProgramFiles 'SAP\FrontEnd\SAPgui\saplgpad.exe') }
  if ($pf86) { $common += (Join-Path $pf86 'SAP\FrontEnd\SAPgui\saplgpad.exe') }
  foreach ($candidateRaw in $common) {
    $candidate = Normalize-PathCandidate $candidateRaw
    if ($candidate) { $Config.sapExecutablePath = $candidate; Save-BridgeConfig $Config; return $candidate }
  }

  $uninstallRoots = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
  )
  foreach ($root in $uninstallRoots) {
    try {
      $apps = Get-ItemProperty $root -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'SAP GUI|SAP Frontend|SAP Business Client' }
      foreach ($app in $apps) {
        if ($app.InstallLocation) {
          $candidate = Normalize-PathCandidate ([string]$app.InstallLocation)
          if ($candidate) { $Config.sapExecutablePath = $candidate; Save-BridgeConfig $Config; return $candidate }
        }
      }
    } catch {}
  }

  $startRoots = @(
    (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs')
  )
  foreach ($root in $startRoots) {
    try {
      if (-not (Test-Path $root)) { continue }
      $links = Get-ChildItem -LiteralPath $root -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^SAP Logon|SAP GUI|SAP Business Client' }
      foreach ($lnk in $links) {
        $candidate = Resolve-ShortcutTarget $lnk.FullName
        if ($candidate) { $Config.sapExecutablePath = $candidate; Save-BridgeConfig $Config; return $candidate }
      }
    } catch {}
  }

  return $null
}

function Get-ComChild {
  param($Parent, [int]$Index)
  try { return $Parent.Children($Index) } catch {}
  try { return $Parent.Children.Item($Index) } catch {}
  return $null
}

function Get-SapStatusBar {
  param($Session)
  $out = @{ text = ''; type = '' }
  try {
    $bar = $Session.findById('wnd[0]/sbar')
    $out.text = [string]$bar.Text
    $out.type = [string]$bar.MessageType
  } catch {}
  return $out
}

function Test-SapLoginScreen {
  param($Session)
  # A tela de logon pode variar entre ambientes. Só classificamos como login
  # quando encontramos campos típicos de autenticação na janela principal.
  foreach ($id in @(
    'wnd[0]/usr/txtRSYST-BNAME',
    'wnd[0]/usr/pwdRSYST-BCODE',
    'wnd[0]/usr/txtRSYST-MANDT'
  )) {
    try { $null = $Session.findById($id); return $true } catch {}
  }
  return $false
}

function Get-SapScriptingApplication {
  # V1.0.6 — SAP GUI 7.50/7.60/8.x:
  # O caminho mais compatível é consultar a Running Object Table pelo
  # SapROTWr.SapROTWrapper fornecido pelo próprio SAP. Isso também reduz
  # problemas de 32/64 bits entre PowerShell e SAP GUI.
  $sapGuiAuto = $null
  $app = $null
  $rotError = $null
  $marshalError = $null

  try {
    $rotWrapper = New-Object -ComObject 'SapROTWr.SapROTWrapper' -ErrorAction Stop
    $sapGuiAuto = $rotWrapper.GetROTEntry('SAPGUI')
    if ($null -ne $sapGuiAuto) {
      $app = $sapGuiAuto.GetScriptingEngine
      if ($null -ne $app) {
        Write-BridgeLog 'SAP scripting engine obtained via SapROTWr.SapROTWrapper.'
        return $app
      }
    }
  } catch {
    $rotError = $_.Exception.Message
    Write-BridgeLog ('SapROTWr failed: ' + $rotError)
  }

  # Fallback para ambientes onde o ProgID SAPGUI está corretamente
  # registrado na ROT global do Windows.
  try {
    $sapGuiAuto = [Runtime.InteropServices.Marshal]::GetActiveObject('SAPGUI')
    if ($null -ne $sapGuiAuto) {
      $app = $sapGuiAuto.GetScriptingEngine
      if ($null -ne $app) {
        Write-BridgeLog 'SAP scripting engine obtained via Marshal.GetActiveObject.'
        return $app
      }
    }
  } catch {
    $marshalError = $_.Exception.Message
    Write-BridgeLog ('Marshal.GetActiveObject failed: ' + $marshalError)
  }

  # Guardamos o diagnóstico para diferenciar:
  # SAP aberto mas ainda sem sessão x SAP Scripting indisponível.
  $script:LastSapScriptingDiagnostic = @{
    rot = $rotError
    marshal = $marshalError
  }
  return $null
}

function Get-SapSession {
  $app = Get-SapScriptingApplication
  if ($null -eq $app) {
    $sapProcesses = @(Get-Process -Name saplogon,saplgpad,sapgui,sapshcut -ErrorAction SilentlyContinue)
    $running = $sapProcesses.Count -gt 0
    $guiRunning = @($sapProcesses | Where-Object { $_.ProcessName -ieq 'sapgui' }).Count -gt 0
    $State.sapRunning = $running
    $State.sessionConnected = $false

    # Se sapgui.exe (a sessão propriamente dita, e não só SAP Logon) já está
    # rodando e ainda assim não existe engine de scripting, o usuário já pode
    # estar autenticado. Nesse caso não mostramos eternamente "aguardando login".
    if ($guiRunning) {
      $diag = ''
      try {
        if ($script:LastSapScriptingDiagnostic) {
          $diag = 'ROT: ' + [string]$script:LastSapScriptingDiagnostic.rot + ' | Marshal: ' + [string]$script:LastSapScriptingDiagnostic.marshal
        }
      } catch {}
      Write-BridgeLog ('sapgui.exe is running but scripting engine is unavailable. ' + $diag)
      Set-BridgeError 'SAP_SCRIPTING_UNAVAILABLE' 'SAP aberto, mas a automação não consegue acessar a sessão' 'O HAPCAPEX detectou o SAP Easy Access aberto, porém o SAP GUI Scripting não está acessível para esta sessão.' 'No SAP, verifique se o Scripting está habilitado. Se a opção estiver bloqueada ou desabilitada, solicite à T.I. a liberação do SAP GUI Scripting no cliente e no servidor.' 'connect_session'
    }
    return $null
  }

  $State.sapRunning = $true
  $connCount = 0
  try { $connCount = [int]$app.Children.Count } catch {
    Set-BridgeError 'SAP_SCRIPTING_DISABLED' 'SAP GUI Scripting indisponível' 'O SAP está aberto, mas não foi possível enumerar as conexões de automação.' 'Solicite à T.I. a liberação do SAP GUI Scripting para seu usuário/ambiente.' 'connect_session'
    return $null
  }

  if ($connCount -lt 1) {
    $State.sessionConnected = $false
    $guiRunning = @(Get-Process -Name sapgui -ErrorAction SilentlyContinue).Count -gt 0
    Write-BridgeLog ("SAP scripting engine visible, but connection count is 0. sapguiRunning={0}" -f $guiRunning)
    if ($guiRunning) {
      Set-BridgeError 'SAP_SCRIPTING_NO_CONNECTIONS' 'SAP Easy Access aberto, mas nenhuma conexão está visível para automação' 'O HAPCAPEX conseguiu acessar o mecanismo SAP GUI Scripting, porém ele informou 0 conexões, mesmo com o SAP Easy Access aberto.' 'Verifique no SAP GUI: Opções → Acessibilidade e Scripting → Scripting → Habilitar Scripting. Se a opção estiver bloqueada ou se continuar com 0 conexões, solicite à T.I. a liberação de SAP GUI Scripting no cliente e no servidor.' 'connect_session'
    }
    return $null
  }

  $candidates = @()
  for ($i=0; $i -lt $connCount; $i++) {
    $connection = Get-ComChild $app $i
    if ($null -eq $connection) { continue }
    $sessionCount = 0
    try { $sessionCount = [int]$connection.Children.Count } catch { continue }
    for ($j=0; $j -lt $sessionCount; $j++) {
      $session = Get-ComChild $connection $j
      if ($null -eq $session) { continue }
      if (Test-SapLoginScreen $session) { continue }

      $systemName=''; $transaction=''; $user=''; $client=''; $busy=$false
      try { $systemName=[string]$session.Info.SystemName } catch {}
      try { $transaction=[string]$session.Info.Transaction } catch {}
      try { $user=[string]$session.Info.User } catch {}
      try { $client=[string]$session.Info.Client } catch {}
      try { $busy=[bool]$session.Busy } catch {}

      Write-BridgeLog ("SAP session candidate conn={0} session={1} system={2} client={3} user={4} tx={5} busy={6}" -f $i,$j,$systemName,$client,$user,$transaction,$busy)

      # Após autenticação, SAP Easy Access normalmente expõe SystemName/User/Client
      # mesmo quando Transaction está vazia ou é SESSION_MANAGER.
      # Uma sessão Easy Access válida deve possuir ao menos um identificador
      # de sistema/cliente/usuário/transação. Não exigimos Transaction porque
      # no menu inicial alguns ambientes deixam esse campo vazio.
      if ($systemName -or $user -or $client -or $transaction) {
        $score = 0
        if ($user) { $score += 8 }
        if ($systemName) { $score += 4 }
        if ($client) { $score += 2 }
        if ($transaction) { $score += 1 }
        if (-not $busy) { $score += 1 }
        $candidates += [pscustomobject]@{ Session=$session; Score=$score; Transaction=$transaction; User=$user; System=$systemName }
      }
    }
  }

  if ($candidates.Count -gt 0) {
    $best = $candidates | Sort-Object Score -Descending | Select-Object -First 1
    $State.sessionConnected = $true
    $State.transaction = [string]$best.Transaction
    Touch-State
    Write-BridgeLog ("Authenticated SAP session selected system={0} user={1} tx={2}" -f $best.System,$best.User,$best.Transaction)
    return $best.Session
  }

  $State.sessionConnected = $false
  return $null
}

function Start-SapGui {
  param([string]$ManualPath = '')
  Set-BridgeState 'working' 'locate_sap' 'Localizando o SAP GUI neste computador...'
  $path = Find-SapExecutable $ManualPath
  if (-not $path) {
    $State.sapFound = $false
    $State.sapPath = $null
    Set-BridgeError 'SAP_NOT_FOUND' 'SAP não localizado' 'Não encontrei o SAP GUI neste computador.' 'Instale o SAP GUI junto à T.I. ou informe a pasta/arquivo onde o SAP está instalado.' 'locate_sap'
    return $false
  }
  $State.sapFound = $true
  $State.sapPath = $path
  $alreadyRunning = @(Get-Process -Name saplogon,saplgpad,sapgui,sapshcut -ErrorAction SilentlyContinue).Count -gt 0
  if ($alreadyRunning) {
    $State.sapRunning = $true
    Set-BridgeState 'awaiting_login' 'login' 'SAP já está aberto. Faça login na janela do SAP; o HAPCAPEX reconhecerá a nova sessão automaticamente.'
    return $true
  }
  Set-BridgeState 'working' 'open_sap' 'SAP localizado. Abrindo o aplicativo...'
  try {
    Start-Process -FilePath $path | Out-Null
  } catch {
    Set-BridgeError 'SAP_OPEN_FAILED' 'Não foi possível abrir o SAP' $_.Exception.Message 'Verifique a instalação do SAP GUI ou solicite suporte à T.I.' 'open_sap'
    return $false
  }
  Start-Sleep -Milliseconds 900
  Set-BridgeState 'awaiting_login' 'login' 'SAP aberto. Entre no ambiente SAP normalmente com seu usuário e senha. Pode deixar o SAP Logon aberto: quando a janela SAP Easy Access aparecer, o HAPCAPEX continuará automaticamente.'
  return $true
}

function Refresh-SapSessionState {
  # LEGADO INATIVO desde V1.0.7.
  # Mantido apenas para compatibilidade interna; o estado SAP é controlado
  # exclusivamente pelo MacroBridge via endpoints explícitos.
  return
}

function Open-BudconTransaction {
  $session = Get-SapSession
  if ($null -eq $session) {
    Set-BridgeError 'SAP_LOGIN_REQUIRED' 'Login no SAP necessário' 'Ainda não encontrei uma sessão SAP autenticada.' 'Faça login no SAP com seu usuário e senha e tente novamente.' 'open_transaction'
    return $false
  }

  $code = [string]$Config.preferredTransactionCode
  if ([string]::IsNullOrWhiteSpace($code)) { $code = $DefaultTransaction }
  Set-BridgeState 'working' 'open_transaction' ("Abrindo a transação $code...")

  $opened = $false
  try {
    $session.StartTransaction($code)
    Start-Sleep -Milliseconds 700
    $opened = $true
  } catch {
    try {
      $ok = $session.findById('wnd[0]/tbar[0]/okcd')
      $ok.Text = '/n' + $code
      $session.findById('wnd[0]').sendVKey(0)
      Start-Sleep -Milliseconds 700
      $opened = $true
    } catch {}
  }

  $status = Get-SapStatusBar $session
  $statusUpper = ([string]$status.text).ToUpperInvariant()
  if ($statusUpper -match 'NÃO.*AUTORIZ|NAO.*AUTORIZ|NOT AUTHORIZ|NO AUTHORIZ|SEM AUTORIZ') {
    Set-BridgeError 'SAP_TRANSACTION_UNAUTHORIZED' 'Usuário sem acesso à transação' $status.text 'Abra um chamado junto à T.I. solicitando acesso à transação FMRP_RW_BUDCON.' 'open_transaction'
    return $false
  }
  if ($statusUpper -match 'TRANSA.*NÃO EXIST|TRANSA.*NAO EXIST|DOES NOT EXIST|UNKNOWN TRANSACTION|NÃO EXISTE') {
    Set-BridgeError 'SAP_TRANSACTION_NOT_FOUND' 'Transação não encontrada' $status.text 'Abra a transação manualmente apenas desta vez. Depois clique em “Já abri a transação”; o Bridge gravará a transação atual para as próximas execuções.' 'open_transaction'
    return $false
  }

  $current = ''
  try { $current = [string]$session.Info.Transaction } catch {}
  if ($opened -and -not [string]::IsNullOrWhiteSpace($current) -and $current -notmatch '^S000$') {
    $State.transaction = $current
    Set-BridgeState 'transaction_ready' 'transaction_ready' ("Transação pronta: $current")
    return $true
  }

  Set-BridgeError 'SAP_TRANSACTION_MANUAL_REQUIRED' 'Abra a transação manualmente' 'O SAP está autenticado, mas não consegui confirmar a abertura automática da transação.' 'Abra FMRP_RW_BUDCON manualmente no SAP e depois clique em “Já abri a transação”.' 'open_transaction'
  return $false
}

function Confirm-ManualTransaction {
  # V1.0.7 — não volta ao mecanismo COM do PowerShell.
  # O MacroBridge já devolve a transação atual em PROBE.
  $r = Invoke-MacroSapHelper -Action 'probe' -TimeoutSeconds 12
  if (-not $r -or -not $r.ok) {
    $detail = if($r){$r.message}else{'Helper SAP não retornou diagnóstico.'}
    Set-BridgeError 'SAP_TRANSACTION_NOT_CONFIRMED' 'Transação ainda não identificada' $detail 'Abra a FMRP_RW_BUDCON manualmente e tente novamente.' 'confirm_manual_transaction'
    return $false
  }

  $current = ''
  if ($r.parts.Count -gt 5) { $current = [string]$r.parts[5] }
  if ([string]::IsNullOrWhiteSpace($current) -or $current -in @('S000','SESSION_MANAGER')) {
    Set-BridgeError 'SAP_TRANSACTION_NOT_CONFIRMED' 'Transação ainda não identificada' ("Transação atual: {0}" -f $current) 'Abra a FMRP_RW_BUDCON manualmente e tente novamente.' 'confirm_manual_transaction'
    return $false
  }

  $Config.preferredTransactionCode = $current
  Save-BridgeConfig $Config
  $State.sessionConnected = $true
  $State.transaction = $current
  Set-BridgeState 'transaction_ready' 'transaction_ready' ("Transação manual confirmada e gravada: $current")
  return $true
}

function Invoke-SapElementAction {
  param($Session, [string]$Id, [scriptblock]$Action, [string]$Step)
  try {
    $element = $Session.findById($Id)
    & $Action $element
  } catch {
    throw (New-Object Exception ("SAP_ELEMENT_NOT_FOUND|$Step|$Id|" + $_.Exception.Message))
  }
}

function Wait-ExportFile {
  param([string]$Path, [int]$TimeoutSeconds = 180)
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while ((Get-Date) -lt $deadline) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
      try {
        $fi = Get-Item -LiteralPath $Path
        if ($fi.Length -gt 0) {
          $stream = [IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
          $stream.Close()
          return $true
        }
      } catch {}
    }
    Start-Sleep -Milliseconds 500
  }
  return $false
}

function Export-BaseConsumo {
  param([int]$Year)
  if ($Year -lt 2000 -or $Year -gt 2100) { $Year = (Get-Date).Year }
  $session = Get-SapSession
  if ($null -eq $session) {
    Set-BridgeError 'SAP_LOGIN_REQUIRED' 'Login no SAP necessário' 'Não encontrei sessão autenticada para executar a Base Consumo.' 'Faça login no SAP e tente novamente.' 'export_consumo'
    return $false
  }

  $State.state = 'exporting'
  $State.currentStep = 'fill_budcon'
  $State.message = 'Preenchendo parâmetros da FMRP_RW_BUDCON...'
  $State.lastError = $null
  Touch-State

  try {
    try { $session.findById('wnd[0]').maximize() } catch {}

    Invoke-SapElementAction $session 'wnd[0]/usr/ctxt$4FFIKRS' { param($e) $e.Text = 'HAPV' } 'fill_fund'
    Invoke-SapElementAction $session 'wnd[0]/usr/txt$4FFYEAR' { param($e) $e.Text = [string]$Year } 'fill_year'
    Invoke-SapElementAction $session 'wnd[0]/usr/ctxt_4FFIPEX-LOW' { param($e) $e.Text = 'sho_obras'; $e.SetFocus(); $e.caretPosition = 9 } 'fill_program'

    $State.currentStep = 'execute_budcon'; $State.message = 'Executando o relatório de utilização do orçamento...'; Touch-State
    $session.findById('wnd[0]').sendVKey(8)
    Start-Sleep -Milliseconds 900

    $status = Get-SapStatusBar $session
    $statusUpper = ([string]$status.text).ToUpperInvariant()
    if ($statusUpper -match 'NÃO.*AUTORIZ|NAO.*AUTORIZ|NOT AUTHORIZ|SEM AUTORIZ') {
      Set-BridgeError 'SAP_TRANSACTION_UNAUTHORIZED' 'Usuário sem acesso à transação' $status.text 'Abra um chamado junto à T.I. solicitando acesso à FMRP_RW_BUDCON.' 'execute_budcon'
      return $false
    }

    $State.currentStep = 'open_report_detail'; $State.message = 'Abrindo o detalhamento necessário para a Base Consumo...'; Touch-State
    Invoke-SapElementAction $session 'wnd[0]/shellcont/shell/shellcont[1]/shell' { param($e) $e.topNode = '000001' } 'open_report_tree'
    Invoke-SapElementAction $session 'wnd[0]/usr/lbl[65,12]' { param($e) $e.SetFocus(); $e.caretPosition = 7 } 'select_report_line'
    $session.findById('wnd[0]').sendVKey(2)
    Start-Sleep -Milliseconds 350
    Invoke-SapElementAction $session 'wnd[1]/usr/lbl[1,1]' { param($e) $e.caretPosition = 20 } 'confirm_report_line'
    $session.findById('wnd[1]').sendVKey(2)
    Start-Sleep -Milliseconds 350

    $State.currentStep = 'select_layout'; $State.message = 'Localizando o layout obrigatório /IRLANDO...'; Touch-State
    Invoke-SapElementAction $session 'wnd[0]/tbar[1]/btn[33]' { param($e) $e.press() } 'open_layout_dialog'
    Start-Sleep -Milliseconds 500
    $layoutId = 'wnd[1]/usr/subSUB_CONFIGURATION:SAPLSALV_CUL_LAYOUT_CHOOSE:0500/cntlD500_CONTAINER/shellcont/shell'
    $shellLayout = $session.findById($layoutId)
    $rowCount = [int]$shellLayout.RowCount
    $layoutRow = -1
    for ($i=0; $i -lt $rowCount; $i++) {
      $value = ''
      try { $value = ([string]$shellLayout.GetCellValue($i,'LAYOUT')).Trim().ToUpperInvariant() } catch {}
      if ($value -eq $ExpectedLayout.ToUpperInvariant()) { $layoutRow = $i; break }
    }
    if ($layoutRow -lt 0) {
      try { $session.findById('wnd[1]/tbar[0]/btn[12]').press() } catch {}
      Set-BridgeError 'SAP_LAYOUT_NOT_FOUND' 'Layout /IRLANDO não encontrado' 'A extração foi interrompida porque o layout obrigatório /IRLANDO não apareceu na lista.' 'Verifique se o layout /IRLANDO está disponível para seu usuário. Não selecione outro layout; solicite suporte à T.I. ou à equipe responsável pelo SAP.' 'select_layout'
      return $false
    }
    $shellLayout.setCurrentCell($layoutRow,'TEXT')
    if ($layoutRow -gt 5) { $shellLayout.firstVisibleRow = $layoutRow - 5 } else { $shellLayout.firstVisibleRow = 0 }
    $shellLayout.selectedRows = [string]$layoutRow
    $shellLayout.clickCurrentCell()
    Start-Sleep -Milliseconds 550

    $State.currentStep = 'export_excel'; $State.message = 'Exportando a Base Consumo para Excel...'; Touch-State
    Invoke-SapElementAction $session 'wnd[0]/tbar[1]/btn[46]' { param($e) $e.press() } 'prepare_export'
    Invoke-SapElementAction $session 'wnd[0]/tbar[1]/btn[43]' { param($e) $e.press() } 'open_export_dialog'
    Start-Sleep -Milliseconds 400

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $baseName = 'base consumo ' + $stamp
    $expectedFile = Join-Path $ExportDir ($baseName + '.xlsx')
    if (Test-Path -LiteralPath $expectedFile) { Remove-Item -LiteralPath $expectedFile -Force }

    Invoke-SapElementAction $session 'wnd[1]/usr/ssubSUB_CONFIGURATION:SAPLSALV_GUI_CUL_EXPORT_AS:0512/txtGS_EXPORT-FILE_NAME' { param($e) $e.Text = $baseName } 'set_export_name'
    try { $session.findById('wnd[1]/usr/ssubSUB_CONFIGURATION:SAPLSALV_GUI_CUL_EXPORT_AS:0512/cmbGS_EXPORT-DESTINATION').SetFocus() } catch {}
    Invoke-SapElementAction $session 'wnd[1]/tbar[0]/btn[20]' { param($e) $e.press() } 'open_export_path'
    Start-Sleep -Milliseconds 250
    Invoke-SapElementAction $session 'wnd[1]/usr/ctxtDY_PATH' { param($e) $e.Text = $ExportDir; $e.SetFocus(); $e.caretPosition = 0 } 'set_export_path'
    Invoke-SapElementAction $session 'wnd[1]/tbar[0]/btn[11]' { param($e) $e.press() } 'confirm_export'

    $State.currentStep = 'wait_export'; $State.message = 'Aguardando o SAP concluir a gravação do Excel...'; Touch-State
    if (-not (Wait-ExportFile $expectedFile 180)) {
      Set-BridgeError 'SAP_EXPORT_TIMEOUT' 'Arquivo da Base Consumo não foi concluído' 'O SAP não gerou/liberou o arquivo Excel dentro do tempo esperado.' 'Verifique se existe alguma janela do SAP/Excel aguardando confirmação e tente novamente.' 'wait_export'
      return $false
    }

    $fileInfo = Get-Item -LiteralPath $expectedFile
    $State.exportFile = $expectedFile
    $State.exportFileName = $fileInfo.Name
    $State.exportBytes = [int64]$fileInfo.Length
    Set-BridgeState 'export_ready' 'export_ready' ("Base Consumo exportada: $($fileInfo.Name)")
    $Config.lastSuccessfulLayout = $ExpectedLayout
    Save-BridgeConfig $Config

    # Limpeza conservadora: remove somente exports locais com mais de 14 dias.
    try { Get-ChildItem -LiteralPath $ExportDir -Filter '*.xlsx' -File | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-14) } | Remove-Item -Force -ErrorAction SilentlyContinue } catch {}
    return $true
  } catch {
    $raw = $_.Exception.Message
    if ($raw -like 'SAP_ELEMENT_NOT_FOUND|*') {
      $parts = $raw.Split('|',4)
      $step = if ($parts.Count -gt 1) { $parts[1] } else { 'sap_screen' }
      $id = if ($parts.Count -gt 2) { $parts[2] } else { '' }
      Set-BridgeError 'SAP_SCREEN_CHANGED' 'Tela SAP diferente do padrão esperado' ("Não encontrei um elemento esperado do SAP durante a etapa '$step'. Elemento: $id") 'Volte à tela inicial da FMRP_RW_BUDCON e tente novamente. Se persistir, o ambiente SAP pode ter mudado e o mapeamento do Bridge precisará ser atualizado.' $step
    } else {
      Set-BridgeError 'SAP_EXPORT_FAILED' 'Falha ao extrair Base Consumo' $raw 'Tente novamente. Se persistir, consulte o log do SAP Bridge e envie o erro à equipe responsável pelo HAPCAPEX.' 'export_consumo'
    }
    return $false
  }
}


function ConvertTo-BridgeTokenHash {
  param([Parameter(Mandatory=$true)][string]$Token)
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Token)))).Replace('-','').ToLowerInvariant() }
  finally { $sha.Dispose() }
}
function New-BridgePairToken {
  $bytes = New-Object byte[] 32
  $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
  try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
  return ([Convert]::ToBase64String($bytes)).TrimEnd('=').Replace('+','-').Replace('/','_')
}
function Clear-ExpiredBridgeSessions {
  $now=[DateTimeOffset]::UtcNow
  foreach($key in @($BridgeSessions.Keys)){ $entry=$BridgeSessions[$key]; if($null -eq $entry -or [DateTimeOffset]$entry.expiresAt -le $now){ [void]$BridgeSessions.Remove($key) } }
}
function Validate-HapcapexSupabaseSession {
  param([Parameter(Mandatory=$true)][string]$AccessToken)
  if([string]::IsNullOrWhiteSpace($AccessToken) -or $AccessToken.Length -lt 40 -or $AccessToken.Length -gt 8192){ throw 'Sessão HAPCAPEX inválida.' }
  try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12 } catch {}
  $headers=@{Authorization=('Bearer '+$AccessToken);apikey=$SupabaseAnonKey;Accept='application/json'}
  try { $user=Invoke-RestMethod -Uri ($SupabaseUrl+'/auth/v1/user') -Method Get -Headers $headers -TimeoutSec 10 } catch { throw 'Não foi possível validar a sessão HAPCAPEX no Supabase.' }
  $uid=[string]$user.id; if([string]::IsNullOrWhiteSpace($uid)){ throw 'Usuário HAPCAPEX não identificado.' }
  try { $profileUri=$SupabaseUrl+'/rest/v1/profiles?select=id,role,is_active,deleted_at,must_change_password&id=eq.'+[Uri]::EscapeDataString($uid)+'&limit=1'; $profiles=@(Invoke-RestMethod -Uri $profileUri -Method Get -Headers $headers -TimeoutSec 10) } catch { throw 'Não foi possível validar o perfil HAPCAPEX.' }
  $profile=$profiles|Select-Object -First 1
  if($null -eq $profile){ throw 'Perfil HAPCAPEX não encontrado.' }
  if($profile.is_active -ne $true){ throw 'Usuário HAPCAPEX inativo.' }
  if($profile.deleted_at){ throw 'Usuário HAPCAPEX removido.' }
  if($profile.must_change_password -eq $true){ throw 'Troque a senha provisória no HAPCAPEX antes de usar o SAP Bridge.' }
  $role=[string]$profile.role; if($role -notin @('admin','viewer')){ throw 'Perfil sem permissão para usar o SAP Bridge.' }
  return [pscustomobject]@{userId=$uid;email=[string]$user.email;role=$role}
}
function New-AuthorizedBridgeSession {
  param([Parameter(Mandatory=$true)]$Identity,[Parameter(Mandatory=$true)][string]$Origin)
  Clear-ExpiredBridgeSessions
  $token=New-BridgePairToken; $hash=ConvertTo-BridgeTokenHash $token; $expires=[DateTimeOffset]::UtcNow.AddMinutes($BridgePairTtlMinutes)
  $BridgeSessions[$hash]=[pscustomobject]@{userId=[string]$Identity.userId;email=[string]$Identity.email;role=[string]$Identity.role;origin=$Origin;createdAt=[DateTimeOffset]::UtcNow;expiresAt=$expires}
  return [pscustomobject]@{token=$token;expiresAt=$expires;role=[string]$Identity.role;email=[string]$Identity.email}
}
function Get-AuthorizedBridgeSession {
  param($Request)
  Clear-ExpiredBridgeSessions
  if($null -eq $Request -or -not $Request.headers.ContainsKey('x-hapcapex-bridge-token')){ return $null }
  $token=[string]$Request.headers['x-hapcapex-bridge-token']; if([string]::IsNullOrWhiteSpace($token) -or $token.Length -gt 256){ return $null }
  $hash=ConvertTo-BridgeTokenHash $token; if(-not $BridgeSessions.ContainsKey($hash)){ return $null }
  $entry=$BridgeSessions[$hash]
  $requestOrigin=if($Request.headers.ContainsKey('origin')){[string]$Request.headers['origin']}else{''}
  if([string]::IsNullOrWhiteSpace($requestOrigin) -or $requestOrigin -ne [string]$entry.origin){ return $null }
  if([DateTimeOffset]$entry.expiresAt -le [DateTimeOffset]::UtcNow){ [void]$BridgeSessions.Remove($hash); return $null }
  $entry.expiresAt=[DateTimeOffset]::UtcNow.AddMinutes($BridgePairTtlMinutes)
  return $entry
}

function Is-OriginAllowed {
  param([string]$Origin)
  if ([string]::IsNullOrWhiteSpace($Origin)) { return $true }
  foreach ($allowed in @($Config.allowedOrigins)) {
    if ($Origin -eq [string]$allowed) { return $true }
  }
  return $false
}

function Get-HttpReason {
  param([int]$Status)
  switch ($Status) {
    200 { 'OK' }
    204 { 'No Content' }
    400 { 'Bad Request' }
    401 { 'Unauthorized' }
    403 { 'Forbidden' }
    404 { 'Not Found' }
    409 { 'Conflict' }
    500 { 'Internal Server Error' }
    default { 'OK' }
  }
}

function Write-HttpResponse {
  param(
    [System.Net.Sockets.NetworkStream]$Stream,
    [int]$Status = 200,
    [string]$ContentType = 'application/json; charset=utf-8',
    [byte[]]$BodyBytes = $null,
    [string]$Origin = ''
  )
  if ($null -eq $BodyBytes) { $BodyBytes = New-Object byte[] 0 }
  $headers = New-Object System.Collections.Generic.List[string]
  $headers.Add(('HTTP/1.1 {0} {1}' -f $Status,(Get-HttpReason $Status)))
  $headers.Add(('Content-Type: ' + $ContentType))
  $headers.Add(('Content-Length: ' + $BodyBytes.Length))
  $headers.Add('Cache-Control: no-store')
  $headers.Add('Connection: close')
  if ($Origin -and (Is-OriginAllowed $Origin)) {
    $headers.Add(('Access-Control-Allow-Origin: ' + $Origin))
    $headers.Add('Vary: Origin')
  }
  $headers.Add('Access-Control-Allow-Methods: GET, POST, OPTIONS')
  $headers.Add('Access-Control-Allow-Headers: Content-Type, X-HAPCAPEX-Client, X-HAPCAPEX-Bridge-Token')
  $headers.Add('Access-Control-Allow-Private-Network: true')
  $headText = (($headers -join "`r`n") + "`r`n`r`n")
  $headBytes = [Text.Encoding]::ASCII.GetBytes($headText)
  $Stream.Write($headBytes,0,$headBytes.Length)
  if ($BodyBytes.Length -gt 0) { $Stream.Write($BodyBytes,0,$BodyBytes.Length) }
  $Stream.Flush()
}

function Write-JsonResponse {
  param($Stream, $Object, [int]$Status = 200, [string]$Origin = '')
  $json = $Object | ConvertTo-Json -Depth 8 -Compress
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  Write-HttpResponse $Stream $Status 'application/json; charset=utf-8' $bytes $Origin
}

function Read-HttpRequest {
  param([System.Net.Sockets.NetworkStream]$Stream)
  $reader = New-Object IO.StreamReader -ArgumentList @($Stream,[Text.Encoding]::UTF8,$false,4096,$true)
  $first = $reader.ReadLine()
  if (-not $first) { return $null }
  if ($first.Length -gt 4096) { throw 'HTTP request line too large.' }
  $parts = $first.Split(' ')
  if ($parts.Count -lt 2) { return $null }
  $method = $parts[0].ToUpperInvariant()
  $rawPath = $parts[1]
  $headers = @{}
  $headerCount = 0
  while ($true) {
    $line = $reader.ReadLine()
    if ($null -eq $line -or $line -eq '') { break }
    $headerCount += 1
    if ($headerCount -gt 100 -or $line.Length -gt 8192) { throw 'HTTP headers too large.' }
    $idx = $line.IndexOf(':')
    if ($idx -gt 0) { $headers[$line.Substring(0,$idx).Trim().ToLowerInvariant()] = $line.Substring($idx+1).Trim() }
  }
  $body = ''
  $length = 0
  if ($headers.ContainsKey('content-length')) { [int]::TryParse([string]$headers['content-length'],[ref]$length) | Out-Null }
  if ($length -lt 0 -or $length -gt 65536) { throw 'HTTP request body too large.' }
  if ($length -gt 0) {
    $buffer = New-Object char[] $length
    $read = 0
    while ($read -lt $length) {
      $n = $reader.Read($buffer,$read,$length-$read)
      if ($n -le 0) { break }
      $read += $n
    }
    if ($read -gt 0) { $body = -join ($buffer[0..($read-1)]) }
  }
  return @{ method=$method; path=$rawPath; headers=$headers; body=$body }
}

function Get-PublicState {
  # V1.0.7: STATUS É SOMENTE LEITURA.
  # Não tenta redetectar sessão aqui; isso impedia o MacroBridge de manter
  # session_ready porque o método PowerShell legado rebaixava o estado.
  $runningNow = @(Get-Process -Name saplogon,saplgpad,sapgui,sapshcut -ErrorAction SilentlyContinue).Count -gt 0
  return @{
    version = $State.version
    processId = $State.processId
    startedAt = $State.startedAt
    state = $State.state
    currentStep = $State.currentStep
    message = $State.message
    sapFound = $State.sapFound
    sapPath = $State.sapPath
    sapRunning = $runningNow
    sessionConnected = $State.sessionConnected
    transaction = $State.transaction
    dedicatedSessionId = $State.dedicatedSessionId
    dedicatedSessionCreatedAt = $State.dedicatedSessionCreatedAt
    machineName = $State.machineName
    windowsUser = $State.windowsUser
    sapUser = $State.sapUser
    sapSystem = $State.sapSystem
    sapClient = $State.sapClient
    sapWindowTitle = $State.sapWindowTitle
    exportFileName = $State.exportFileName
    exportBytes = $State.exportBytes
    lastError = $State.lastError
    updatedAt = $State.updatedAt
    expectedLayout = $ExpectedLayout
    preferredTransactionCode = [string]$Config.preferredTransactionCode
    sessionEngine = 'MacroBridge-GetObject-SAPGUI'
  }
}

function Handle-HttpRequest {
  param($Request, [System.Net.Sockets.NetworkStream]$Stream)
  $origin = ''
  if ($Request.headers.ContainsKey('origin')) { $origin = [string]$Request.headers['origin'] }
  if ($origin -and -not (Is-OriginAllowed $origin)) {
    Write-JsonResponse $Stream @{ ok=$false; error='Origin not allowed' } 403 ''
    return
  }

  if ($Request.method -eq 'OPTIONS') {
    Write-HttpResponse $Stream 204 'text/plain' ([byte[]]@()) $origin
    return
  }

  $path = ([string]$Request.path).Split('?')[0]
  try {
    if ($Request.method -eq 'GET' -and $path -eq '/api/health') {
      Write-JsonResponse $Stream @{ ok=$true; product='HAPCAPEX SAP Bridge'; version=$BridgeVersion; port=$Port; distribution='corporate'; distributionVersion=$DistributionVersion; pairingRequired=$true; security='supabase-paired-session-v1'; updateProtocol='hapcapex-sap://update' } 200 $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/pair') {
      if ([string]::IsNullOrWhiteSpace($origin)) { Write-JsonResponse $Stream @{ok=$false;error='Origin obrigatório para pareamento.'} 403 ''; return }
      $body=Get-JsonBody $Request.body; $accessToken=if($body -and $body.accessToken){[string]$body.accessToken}else{''}
      if([string]::IsNullOrWhiteSpace($accessToken)){ Write-JsonResponse $Stream @{ok=$false;error='Sessão HAPCAPEX ausente.'} 401 $origin; return }
      try { $identity=Validate-HapcapexSupabaseSession $accessToken; $pair=New-AuthorizedBridgeSession $identity $origin; Write-BridgeLog ('Pareamento autorizado para usuário HAPCAPEX: '+$pair.email+' ('+$pair.role+')'); Write-JsonResponse $Stream @{ok=$true;token=$pair.token;expiresAt=$pair.expiresAt.ToString('o');role=$pair.role;security='supabase-paired-session-v1'} 200 $origin }
      catch { Write-BridgeLog ('Pareamento rejeitado: '+$_.Exception.Message) 'WARN'; Write-JsonResponse $Stream @{ok=$false;error=$_.Exception.Message} 401 $origin }
      return
    }
    $bridgeSession=Get-AuthorizedBridgeSession $Request
    if($null -eq $bridgeSession){ Write-JsonResponse $Stream @{ok=$false;error='SAP Bridge não pareado ou sessão local expirada.';code='BRIDGE_PAIR_REQUIRED'} 401 $origin; return }
    if ($Request.method -eq 'GET' -and $path -eq '/api/status') {
      Write-JsonResponse $Stream @{ ok=$true; status=(Get-PublicState) } 200 $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/find') {
      $body = Get-JsonBody $Request.body
      $manual = if ($body -and $body.manualPath) { [string]$body.manualPath } else { '' }
      $found = Find-SapExecutable $manual
      if ($found) {
        $State.sapFound=$true; $State.sapPath=$found; Set-BridgeState 'sap_found' 'locate_sap' 'SAP GUI localizado.'
        Write-JsonResponse $Stream @{ ok=$true; status=(Get-PublicState) } 200 $origin
      } else {
        $State.sapFound=$false; $State.sapPath=$null
        Set-BridgeError 'SAP_NOT_FOUND' 'SAP não localizado' 'Não encontrei o SAP GUI neste computador.' 'Instale o SAP GUI junto à T.I. ou cole a pasta/arquivo de instalação.' 'locate_sap'
        Write-JsonResponse $Stream @{ ok=$false; status=(Get-PublicState) } 404 $origin
      }
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/open') {
      $body = Get-JsonBody $Request.body
      $manual = if ($body -and $body.manualPath) { [string]$body.manualPath } else { '' }
      $ok = Start-SapGui $manual
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/connect') {
      # V1.0.7 — conexão SAP usa o mesmo GetObject("SAPGUI") da macro.
      # Modo soft: se ainda não houve login, apenas permanece aguardando.
      $ok = Confirm-SapLoginViaMacro $false
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/confirm-login') {
      $State.lastError = $null
      $ok = Confirm-SapLoginViaMacro $true
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/open-transaction') {
      $ok = Open-BudconViaMacro
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/confirm-manual-transaction') {
      $ok = Confirm-ManualTransaction
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/sap/export-consumo') {
      $body = Get-JsonBody $Request.body
      $year = (Get-Date).Year
      if ($body -and $body.year) { try { $year = [int]$body.year } catch {} }
      $ok = Export-BaseConsumoViaMacro $year
      Write-JsonResponse $Stream @{ ok=$ok; status=(Get-PublicState) } $(if($ok){200}else{409}) $origin
      return
    }
    if ($Request.method -eq 'GET' -and $path -eq '/api/export/latest/meta') {
      if (-not $State.exportFile -or -not (Test-Path -LiteralPath $State.exportFile)) {
        Write-JsonResponse $Stream @{ ok=$false; error='Nenhum export disponível.' } 404 $origin
      } else {
        $fi = Get-Item -LiteralPath $State.exportFile
        Write-JsonResponse $Stream @{ ok=$true; fileName=$fi.Name; bytes=[int64]$fi.Length; createdAt=$fi.LastWriteTime.ToString('o') } 200 $origin
      }
      return
    }
    if ($Request.method -eq 'GET' -and $path -eq '/api/export/latest/file') {
      if (-not $State.exportFile -or -not (Test-Path -LiteralPath $State.exportFile)) {
        Write-JsonResponse $Stream @{ ok=$false; error='Nenhum export disponível.' } 404 $origin
      } else {
        $bytes = [IO.File]::ReadAllBytes($State.exportFile)
        Write-HttpResponse $Stream 200 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' $bytes $origin
      }
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/reset') {
      Reset-SapCycle $true $false 'SAP Bridge reiniciado. Pronto para uma nova atualização.'
      Write-JsonResponse $Stream @{ ok=$true; status=(Get-PublicState) } 200 $origin
      return
    }
    if ($Request.method -eq 'POST' -and $path -eq '/api/complete-cycle') {
      Reset-SapCycle $true $true 'Atualização concluída. SAP Bridge pronto para a próxima importação.'
      Write-JsonResponse $Stream @{ ok=$true; status=(Get-PublicState) } 200 $origin
      return
    }

    Write-JsonResponse $Stream @{ ok=$false; error='Endpoint não encontrado.' } 404 $origin
  } catch {
    Write-BridgeLog ('HTTP route exception: ' + $_.Exception.Message) 'ERROR'
    Write-JsonResponse $Stream @{ ok=$false; error=$_.Exception.Message } 500 $origin
  }
}

function Test-PortInUse {
  param([int]$PortNumber)
  try {
    $client = New-Object Net.Sockets.TcpClient
    $iar = $client.BeginConnect('127.0.0.1',$PortNumber,$null,$null)
    $ok = $iar.AsyncWaitHandle.WaitOne(250,$false)
    if ($ok -and $client.Connected) { $client.Close(); return $true }
    $client.Close()
  } catch {}
  return $false
}

if (Test-PortInUse $Port) {
  Write-BridgeLog 'Bridge já está em execução; esta instância será encerrada.'
  exit 0
}

try { Set-Content -LiteralPath $PidPath -Value $PID -Encoding ASCII } catch {}

$listener = New-Object Net.Sockets.TcpListener -ArgumentList @([Net.IPAddress]::Loopback,$Port)
try {
  $listener.Start()
  Write-BridgeLog ("HAPCAPEX SAP Bridge $BridgeVersion iniciado em 127.0.0.1:$Port")
  Set-BridgeState 'idle' 'bridge_ready' 'SAP Bridge pronto.'

  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $client.ReceiveTimeout = 5000
      $client.SendTimeout = 200000
      $stream = $client.GetStream()
      $request = Read-HttpRequest $stream
      if ($null -ne $request) { Handle-HttpRequest $request $stream }
      try { $stream.Close() } catch {}
    } catch {
      Write-BridgeLog ('Falha ao processar conexão local: ' + $_.Exception.Message) 'ERROR'
    } finally {
      try { $client.Close() } catch {}
    }
  }
} finally {
  try { $listener.Stop() } catch {}
  try { Remove-Item -LiteralPath $PidPath -Force -ErrorAction SilentlyContinue } catch {}
  Write-BridgeLog 'Bridge encerrado.'
}
