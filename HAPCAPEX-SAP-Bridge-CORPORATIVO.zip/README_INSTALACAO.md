﻿# HAPCAPEX SAP Bridge Corporativo — V1.1.5-alpha (pacote 1.0.7)

## Instalação piloto
1. Extraia TODO o conteúdo do ZIP para uma pasta local.
2. Execute `Instalar-HAPCAPEX-SAP-Bridge.cmd`.
3. Aguarde a mensagem `Instalação corporativa concluída`.
4. Abra HAPCAPEX > Base Consumo > Atualizar pelo SAP.
5. O topo deve mostrar `Bridge 1.1.5-alpha`.

Não desinstale a versão anterior antes. O instalador faz backup e tenta restaurá-la se a nova versão não responder.

Este pacote 1.0.7 corrige o erro de sintaxe do instalador corporativo inicial.


SEGURANÇA 1.1.5
- Endpoints SAP exigem pareamento temporário com sessão autenticada do HAPCAPEX.
- Token local existe apenas na memória e expira.
- Senha SAP não é lida nem armazenada.
