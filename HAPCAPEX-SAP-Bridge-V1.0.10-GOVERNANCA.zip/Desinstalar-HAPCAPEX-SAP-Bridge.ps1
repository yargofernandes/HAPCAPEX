Set-StrictMode -Version 2.0
$ErrorActionPreference='SilentlyContinue'
$target=Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
Remove-Item -Path 'HKCU:\Software\Classes\hapcapex-sap' -Recurse -Force
$shortcut=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\HAPCAPEX\HAPCAPEX SAP Bridge.lnk'
Remove-Item -LiteralPath $shortcut -Force
Write-Host 'Protocolo e atalho removidos.'
Write-Host ('Os logs/exports permanecem em: ' + $target)
Write-Host 'Apague a pasta manualmente se também quiser remover histórico local.'
