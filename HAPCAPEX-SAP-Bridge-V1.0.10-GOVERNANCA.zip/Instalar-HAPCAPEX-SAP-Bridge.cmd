@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Instalar-HAPCAPEX-SAP-Bridge.ps1"
if errorlevel 1 (
  echo.
  echo Falha na instalacao do HAPCAPEX SAP Bridge.
  pause
  exit /b 1
)
echo.
echo Instalacao concluida. Pode voltar ao HAPCAPEX.
pause
