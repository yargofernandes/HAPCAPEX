﻿param([switch]$NoStart)
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'HAPCAPEX\SapBridge'
New-Item -ItemType Directory -Path $target -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $target 'exports') -Force | Out-Null

# V1.0.2 — atualização é realmente transacional:
# encerra a instância antiga antes de substituir os arquivos e valida a versão servida.
$pidPath = Join-Path $target 'bridge.pid'
$expectedVersion = '1.0.10-alpha'
$port = 17891

function Stop-InstalledBridge {
  $stopped = $false

  if (Test-Path -LiteralPath $pidPath) {
    try {
      $oldPid = [int](Get-Content -LiteralPath $pidPath -Raw -ErrorAction Stop)
      $proc = Get-Process -Id $oldPid -ErrorAction SilentlyContinue
      if ($proc) {
        Write-Host ("Encerrando Bridge anterior (PID {0})..." -f $oldPid) -ForegroundColor Yellow
        Stop-Process -Id $oldPid -Force -ErrorAction Stop
        $stopped = $true
      }
    } catch {}
  }

  # Fallback: identifica quem está ouvindo a porta, mas só encerra se for nosso script.
  try {
    $listener = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
      $owner = [int]$listener.OwningProcess
      $cmd = ''
      try { $cmd = [string](Get-CimInstance Win32_Process -Filter ("ProcessId={0}" -f $owner)).CommandLine } catch {}
      if ($cmd -match 'HAPCAPEX-SAP-Bridge\.ps1') {
        Write-Host ("Encerrando Bridge encontrado na porta {0} (PID {1})..." -f $port,$owner) -ForegroundColor Yellow
        Stop-Process -Id $owner -Force -ErrorAction SilentlyContinue
        $stopped = $true
      }
    }
  } catch {}

  for ($n=0; $n -lt 30; $n++) {
    $busy = $false
    try {
      $tcp = New-Object Net.Sockets.TcpClient
      $iar = $tcp.BeginConnect('127.0.0.1',$port,$null,$null)
      $busy = $iar.AsyncWaitHandle.WaitOne(100,$false) -and $tcp.Connected
      $tcp.Close()
    } catch {}
    if (-not $busy) { break }
    Start-Sleep -Milliseconds 150
  }

  Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
  return $stopped
}

Stop-InstalledBridge | Out-Null

$bridgeSource = Join-Path $source 'HAPCAPEX-SAP-Bridge.ps1'
if (-not (Test-Path -LiteralPath $bridgeSource)) { throw 'HAPCAPEX-SAP-Bridge.ps1 não encontrado ao lado do instalador.' }
Copy-Item -LiteralPath $bridgeSource -Destination (Join-Path $target 'HAPCAPEX-SAP-Bridge.ps1') -Force

$configSource = Join-Path $source 'config.example.json'
if ((Test-Path -LiteralPath $configSource) -and -not (Test-Path -LiteralPath (Join-Path $target 'config.json'))) {
  Copy-Item -LiteralPath $configSource -Destination (Join-Path $target 'config.json')
}

$protocolRoot='HKCU:\Software\Classes\hapcapex-sap'
New-Item -Path $protocolRoot -Force | Out-Null
Set-ItemProperty -Path $protocolRoot -Name '(default)' -Value 'URL:HAPCAPEX SAP Bridge Protocol'
Set-ItemProperty -Path $protocolRoot -Name 'URL Protocol' -Value ''
$commandKey=Join-Path $protocolRoot 'shell\open\command'
New-Item -Path $commandKey -Force | Out-Null
$bridgePath=Join-Path $target 'HAPCAPEX-SAP-Bridge.ps1'
$command='powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $bridgePath + '" -Protocol "%1"'
Set-ItemProperty -Path $commandKey -Name '(default)' -Value $command

$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\HAPCAPEX'
New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
$shortcutPath=Join-Path $startMenu 'HAPCAPEX SAP Bridge.lnk'
$wsh=New-Object -ComObject WScript.Shell
$shortcut=$wsh.CreateShortcut($shortcutPath)
$shortcut.TargetPath='powershell.exe'
$shortcut.Arguments='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "' + $bridgePath + '"'
$shortcut.WorkingDirectory=$target
$shortcut.Description='HAPCAPEX SAP Bridge'
$shortcut.Save()

Write-Host ''
Write-Host 'HAPCAPEX SAP Bridge instalado com sucesso.' -ForegroundColor Green
Write-Host ('Pasta: ' + $target)
Write-Host 'O protocolo hapcapex-sap:// foi registrado somente para seu usuário Windows.'


# V1.0.6 — arquivos auxiliares obrigatorios do Modo Macro
$sourceMacroHelper = Join-Path $PSScriptRoot 'HAPCAPEX-SAP-MacroBridge.vbs'
$targetMacroHelper = Join-Path $target 'HAPCAPEX-SAP-MacroBridge.vbs'
if (-not (Test-Path -LiteralPath $sourceMacroHelper)) {
  Write-Host 'ERRO: HAPCAPEX-SAP-MacroBridge.vbs nao esta no pacote do instalador.' -ForegroundColor Red
  exit 3
}
Copy-Item -LiteralPath $sourceMacroHelper -Destination $targetMacroHelper -Force

$sourceMacroDiag = Join-Path $PSScriptRoot 'Diagnostico-MacroBridge.cmd'
if (Test-Path -LiteralPath $sourceMacroDiag) {
  Copy-Item -LiteralPath $sourceMacroDiag -Destination (Join-Path $target 'Diagnostico-MacroBridge.cmd') -Force
}

if (-not (Test-Path -LiteralPath $targetMacroHelper)) {
  Write-Host 'ERRO: o helper SAP nao foi copiado para a pasta instalada.' -ForegroundColor Red
  exit 4
}

if (-not $NoStart) {
  Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-STA','-File',$bridgePath) | Out-Null


  $installedHelper = Join-Path $target 'HAPCAPEX-SAP-MacroBridge.vbs'
  if (-not (Test-Path -LiteralPath $installedHelper)) {
    Write-Host 'ERRO: Bridge iniciou, mas HAPCAPEX-SAP-MacroBridge.vbs nao esta instalado.' -ForegroundColor Red
    exit 5
  }

  $verified = $false
  $lastVersion = ''
  for ($n=0; $n -lt 30; $n++) {
    Start-Sleep -Milliseconds 250
    try {
      $health = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/api/health" -f $port) -Method Get -TimeoutSec 1
      $lastVersion = [string]$health.version
      if ($health.ok -and $lastVersion -eq $expectedVersion) {
        $verified = $true
        break
      }
    } catch {}
  }

  if (-not $verified) {
    Write-Host ''
    Write-Host ('ATENÇÃO: o Bridge esperado é {0}, mas a versão respondendo foi "{1}".' -f $expectedVersion,$lastVersion) -ForegroundColor Red
    Write-Host 'Feche esta janela e execute o instalador novamente. Se persistir, reinicie o Windows ou envie o bridge.log.' -ForegroundColor Yellow
    exit 2
  }

  Write-Host ('Bridge {0} iniciado e validado com sucesso.' -f $expectedVersion) -ForegroundColor Cyan
}
