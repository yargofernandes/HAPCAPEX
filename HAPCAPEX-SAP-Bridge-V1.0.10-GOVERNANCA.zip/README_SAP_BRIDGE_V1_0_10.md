# HAPCAPEX SAP Bridge V1.0.10-alpha — Governança de execução

Mantém o fluxo de extração validado da V1.0.8 e as melhorias da V1.0.9
(sessão SAP exclusiva e ciclos sucessivos), adicionando metadados de governança.

## Novos campos de status
- machineName
- windowsUser
- sapUser
- sapSystem
- sapClient
- sapWindowTitle
- dedicatedSessionId
- dedicatedSessionCreatedAt
- versão do Bridge

Nenhuma senha SAP é lida ou armazenada. Os dados acima servem exclusivamente
para rastreabilidade da atualização da Base Consumo no HAPCAPEX.
